Graph-Based Algorithms
======================

Graph neural networks for recommendations.

GNN
---

Graph Neural Networks.

See Also
--------

* :doc:`../engines/graph_based` - Graph-based engine

