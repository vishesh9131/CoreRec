Content-Based Algorithms
========================

Detailed documentation of content-based filtering algorithms.

TF-IDF
------

Term Frequency-Inverse Document Frequency for text similarity.

Algorithm Details
^^^^^^^^^^^^^^^^^

TF-IDF represents documents as vectors in a high-dimensional space where each dimension corresponds to a term.

See Also
--------

* :doc:`../engines/content_filter` - Content filter engine
* :doc:`../examples/content_filter_examples` - Examples

