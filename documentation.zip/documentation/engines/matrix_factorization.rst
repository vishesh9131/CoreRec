Matrix Factorization
====================

Matrix factorization algorithms for collaborative filtering in CoreRec.

Overview
--------

Matrix factorization decomposes the user-item interaction matrix into lower-dimensional user and item latent factor matrices.

Available Algorithms
--------------------

SVD (Singular Value Decomposition)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Classic SVD for matrix factorization.

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.mf_base import SVD_base
   
   model = SVD_base.SVD(
       n_factors=50,
       n_epochs=20,
       learning_rate=0.005,
       regularization=0.02
   )
   
   model.fit(ratings)
   prediction = model.predict(user_id=123, item_id=456)

**Key Features:**

* Classic collaborative filtering
* Handles explicit ratings
* Fast and efficient
* Well-studied algorithm

ALS (Alternating Least Squares)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Optimization algorithm for matrix factorization.

.. autoclass:: corerec.engines.unionizedFilterEngine.ALSRecommender
   :members:
   :show-inheritance:

.. code-block:: python

   from corerec.engines.unionizedFilterEngine import ALSRecommender
   
   model = ALSRecommender(
       factors=50,
       regularization=0.01,
       iterations=15,
       alpha=40  # For implicit feedback
   )
   
   model.fit(interactions)
   recommendations = model.recommend(user_id=123, top_k=10)

**Key Features:**

* Efficient for implicit feedback
* Parallelizable
* Handles sparse data well
* Production-ready

NMF (Non-Negative Matrix Factorization)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Matrix factorization with non-negativity constraints.

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.mf_base import nmf_base
   
   model = nmf_base.NMF(
       n_factors=20,
       max_iter=200,
       alpha=0.1,
       l1_ratio=0.5
   )
   
   model.fit(ratings)

**Key Features:**

* Non-negative factors (interpretable)
* Good for parts-based representation
* Useful for topic modeling-like tasks

BPR (Bayesian Personalized Ranking)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Pairwise ranking optimization.

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.mf_base import BPR_base
   
   model = BPR_base.BPR(
       n_factors=50,
       learning_rate=0.01,
       regularization=0.01,
       n_epochs=20
   )
   
   model.fit(implicit_feedback)

**Key Features:**

* Optimized for ranking (not rating prediction)
* Pairwise loss function
* Excellent for implicit feedback
* Used in production systems

PMF (Probabilistic Matrix Factorization)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Probabilistic approach to matrix factorization.

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.mf_base import PMF_base
   
   model = PMF_base.PMF(
       n_factors=10,
       n_epochs=50,
       learning_rate=0.01,
       lambda_u=0.1,
       lambda_v=0.1
   )
   
   model.fit(ratings)

**Key Features:**

* Probabilistic framework
* Handles uncertainty
* Can incorporate priors
* Bayesian inference

Use Cases
---------

Movie Ratings
^^^^^^^^^^^^^

Predict movie ratings (explicit feedback):

.. code-block:: python

   import pandas as pd
   from corerec.engines.unionizedFilterEngine.mf_base import SVD_base
   
   # MovieLens-style data
   ratings = pd.DataFrame({
       'user_id': [...],
       'movie_id': [...],
       'rating': [...],  # 1-5 stars
       'timestamp': [...]
   })
   
   # Train SVD
   model = SVD_base.SVD(n_factors=100, n_epochs=20)
   model.fit(ratings)
   
   # Predict rating
   predicted_rating = model.predict(user_id=1, item_id=50)
   print(f"Predicted rating: {predicted_rating:.2f} stars")
   
   # Get recommendations (highest predicted ratings)
   recommendations = model.recommend(user_id=1, top_k=10)

E-commerce Interactions
^^^^^^^^^^^^^^^^^^^^^^^

Implicit feedback (clicks, purchases):

.. code-block:: python

   from corerec.engines.unionizedFilterEngine import ALSRecommender
   
   # Implicit feedback data
   interactions = pd.DataFrame({
       'user_id': [...],
       'product_id': [...],
       'clicks': [...],  # Number of clicks
       'purchases': [...]  # 0 or 1
   })
   
   # Combine signals
   interactions['confidence'] = (
       interactions['clicks'] + 
       interactions['purchases'] * 10
   )
   
   # Train ALS for implicit feedback
   model = ALSRecommender(
       factors=50,
       regularization=0.01,
       alpha=40  # Confidence scaling
   )
   
   model.fit(interactions)
   recommendations = model.recommend(user_id=123, top_k=10)

Music Recommendations
^^^^^^^^^^^^^^^^^^^^^

Listening history:

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.mf_base import BPR_base
   
   # Listening data
   listens = pd.DataFrame({
       'user_id': [...],
       'song_id': [...],
       'play_count': [...]
   })
   
   # Train BPR (optimized for ranking)
   model = BPR_base.BPR(n_factors=50)
   model.fit(listens)
   
   # Recommend songs
   song_recommendations = model.recommend(user_id=456, top_k=20)

Advanced Features
-----------------

Biased Matrix Factorization
^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Include user and item biases:

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.mf_base import BiasedMF
   
   model = BiasedMF(
       n_factors=50,
       n_epochs=20,
       bias=True  # Include biases
   )
   
   model.fit(ratings)
   
   # Prediction: global_mean + user_bias + item_bias + dot(user_factors, item_factors)
   prediction = model.predict(user_id=1, item_id=100)

Temporal Dynamics
^^^^^^^^^^^^^^^^^

Time-aware matrix factorization:

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.mf_base import TimeSVD
   
   model = TimeSVD(
       n_factors=50,
       n_epochs=20,
       learning_rate=0.005
   )
   
   # Include timestamps
   model.fit(ratings_with_timestamps)
   
   # Predict at specific time
   prediction = model.predict(
       user_id=1,
       item_id=100,
       timestamp='2024-01-01'
   )

Side Information
^^^^^^^^^^^^^^^^

Incorporate user/item features:

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.mf_base import FactorizationMachines
   
   # Data with side information
   data = pd.DataFrame({
       'user_id': [...],
       'item_id': [...],
       'user_age': [...],
       'user_gender': [...],
       'item_category': [...],
       'rating': [...]
   })
   
   model = FactorizationMachines(n_factors=20)
   model.fit(data)

Multi-Task Learning
^^^^^^^^^^^^^^^^^^^^

Learn from multiple objectives:

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.mf_base import MultiTaskMF
   
   model = MultiTaskMF(
       n_factors=50,
       tasks=['rating', 'click', 'purchase'],
       task_weights=[1.0, 0.5, 2.0]
   )
   
   model.fit(multi_task_data)

Hyperparameter Tuning
----------------------

Grid Search
^^^^^^^^^^^

.. code-block:: python

   from sklearn.model_selection import ParameterGrid
   from corerec.evaluation import Evaluator
   
   # Define parameter grid
   param_grid = {
       'n_factors': [20, 50, 100],
       'learning_rate': [0.001, 0.005, 0.01],
       'regularization': [0.01, 0.02, 0.05]
   }
   
   best_score = 0
   best_params = None
   
   for params in ParameterGrid(param_grid):
       model = SVD_base.SVD(**params)
       model.fit(train_data)
       
       evaluator = Evaluator(metrics=['rmse'])
       score = evaluator.evaluate(model, val_data)
       
       if score > best_score:
           best_score = score
           best_params = params
   
   print(f"Best parameters: {best_params}")

Cross-Validation
^^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.evaluation import cross_validate
   
   model = ALSRecommender(factors=50)
   
   scores = cross_validate(
       model,
       data,
       cv=5,
       metrics=['rmse', 'mae', 'precision@10']
   )
   
   print(f"Average RMSE: {scores['rmse'].mean():.4f}")

Optimization Techniques
-----------------------

SGD (Stochastic Gradient Descent)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   model = SVD_base.SVD(
       n_factors=50,
       optimizer='sgd',
       learning_rate=0.005,
       regularization=0.02
   )

ALS (Alternating Least Squares)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   model = ALSRecommender(
       factors=50,
       regularization=0.01,
       iterations=15
   )

Coordinate Descent
^^^^^^^^^^^^^^^^^^

.. code-block:: python

   model = CoordinateDescentMF(
       n_factors=50,
       max_iterations=100,
       regularization=0.01
   )

Best Practices
--------------

1. **Factor Selection**
   
   * Start with 20-50 factors
   * Increase for complex patterns
   * Too many factors → overfitting
   * Use cross-validation to select

2. **Regularization**
   
   * Essential to prevent overfitting
   * Typical values: 0.01-0.1
   * Tune separately for users and items
   * Adjust based on data sparsity

3. **Learning Rate**
   
   * Start with 0.01 for SGD
   * Use learning rate scheduling
   * Monitor convergence
   * Reduce if training unstable

4. **Implicit Feedback**
   
   * Use ALS or BPR for implicit data
   * Set appropriate confidence scaling (alpha)
   * Consider negative sampling
   * Optimize for ranking metrics

5. **Evaluation**
   
   * RMSE/MAE for explicit ratings
   * Precision@k/Recall@k for implicit
   * Use temporal splits
   * Monitor online metrics

Common Issues
-------------

Cold Start Problem
^^^^^^^^^^^^^^^^^^

**Problem:** New users/items with no interactions

**Solutions:**

* Use content-based features (Factorization Machines)
* Implement popularity-based fallback
* Ask for initial preferences
* Use transfer learning from similar users/items

Scalability
^^^^^^^^^^^

**Problem:** Large user/item spaces

**Solutions:**

* Use ALS (parallelizable)
* Implement mini-batch SGD
* Use approximate methods (sampling)
* Distribute computation

Data Sparsity
^^^^^^^^^^^^^

**Problem:** Very few ratings per user/item

**Solutions:**

* Increase regularization
* Use matrix completion techniques
* Incorporate side information
* Apply dimensionality reduction

Model Comparison
----------------

.. list-table::
   :widths: 20 30 30 20
   :header-rows: 1

   * - Algorithm
     - Best For
     - Speed
     - Scalability
   * - SVD
     - Explicit ratings
     - Fast
     - Medium
   * - ALS
     - Implicit feedback
     - Medium
     - High
   * - NMF
     - Interpretable factors
     - Medium
     - Medium
   * - BPR
     - Ranking
     - Fast
     - High
   * - PMF
     - Uncertainty estimation
     - Slow
     - Low

See Also
--------

* :doc:`unionized_filter` - Main engine documentation
* :doc:`../algorithms/collaborative_filtering` - Algorithm details
* :doc:`../examples/unionized_filter_examples` - Usage examples

