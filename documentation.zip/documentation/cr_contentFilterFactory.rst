cr\_contentFilterFactory module
===============================

.. automodule:: cr_contentFilterFactory
   :members:
   :undoc-members:
   :show-inheritance:
