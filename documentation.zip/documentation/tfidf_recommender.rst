tfidf\_recommender module
=========================

.. automodule:: tfidf_recommender
   :members:
   :undoc-members:
   :show-inheritance:
