﻿corerec.api
===========

.. automodule:: corerec.api

   
.. rubric:: Modules

.. autosummary::
   :toctree:
   :recursive:

   base_recommender
   model_interface
   predictor_interface
