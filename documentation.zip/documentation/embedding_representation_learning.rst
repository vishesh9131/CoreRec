embedding\_representation\_learning package
===========================================

Submodules
----------

embedding\_representation\_learning.doc2vec module
--------------------------------------------------

.. automodule:: embedding_representation_learning.doc2vec
   :members:
   :undoc-members:
   :show-inheritance:

embedding\_representation\_learning.personalized\_embeddings module
-------------------------------------------------------------------

.. automodule:: embedding_representation_learning.personalized_embeddings
   :members:
   :undoc-members:
   :show-inheritance:

embedding\_representation\_learning.word2vec module
---------------------------------------------------

.. automodule:: embedding_representation_learning.word2vec
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: embedding_representation_learning
   :members:
   :undoc-members:
   :show-inheritance:
