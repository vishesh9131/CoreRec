Production Pipelines
====================

Build end-to-end recommendation pipelines.

Pipeline Components
-------------------

.. code-block:: python

   from corerec.pipelines import RecommendationPipeline
   
   pipeline = RecommendationPipeline(
       preprocessor=preprocessor,
       model=model,
       postprocessor=postprocessor
   )
   
   pipeline.fit(train_data)
   recommendations = pipeline.recommend(user_id=123)

See Also
--------

* :doc:`serving` - Model serving
* :doc:`../api/overview` - API documentation

