Neural Network Examples
=======================

Examples using deep learning models for recommendations.

DeepFM Example
--------------

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.nn_base import DeepFM_base
   import pandas as pd
   
   # Prepare data with features
   data = pd.DataFrame({
       'user_id': range(1000),
       'item_id': [i % 500 for i in range(1000)],
       'user_age': [20 + i % 40 for i in range(1000)],
       'item_price': [10 + i % 100 for i in range(1000)],
       'clicked': [i % 2 for i in range(1000)]
   })
   
   # Define feature dimensions
   feature_dims = {
       'user_id': 10000,
       'item_id': 50000,
       'user_age': 100,
       'item_price': 1000
   }
   
   # Train DeepFM
   model = DeepFM_base(
       feature_dims=feature_dims,
       embed_dim=16,
       mlp_dims=[128, 64, 32],
       dropout=0.2
   )
   
   model.fit(data, target_column='clicked', epochs=10, batch_size=256)
   
   # Predict CTR
   ctr = model.predict(user_id=123, item_id=456)
   print(f"Predicted CTR: {ctr:.4f}")

DCN Example
-----------

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.nn_base import DCN_base
   
   model = DCN_base(
       feature_dims=feature_dims,
       embed_dim=16,
       n_cross_layers=3,
       mlp_dims=[128, 64]
   )
   
   model.fit(data, epochs=10)

SASRec Example
--------------

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.attention_mechanism_base import SASRec_base
   
   # Sequential data
   sequences = pd.DataFrame({
       'user_id': [1, 1, 1, 1, 2, 2, 2],
       'item_id': [101, 102, 103, 104, 201, 202, 203],
       'timestamp': [1, 2, 3, 4, 1, 2, 3]
   })
   
   # Train SASRec
   model = SASRec_base(
       item_num=1000,
       max_len=50,
       hidden_units=64,
       num_blocks=2,
       num_heads=1
   )
   
   model.fit(sequences, epochs=20)
   
   # Predict next items
   next_items = model.recommend(user_id=1, top_k=5)

Running Examples
----------------

.. code-block:: bash

   # Deep learning examples
   python examples/engines_deepfm_example.py
   python examples/engines_dcn_example.py
   python examples/engines_sasrec_example.py
   python examples/engines_mind_example.py
   python examples/engines_gnnrec_example.py
   python examples/dien_example.py

See Also
--------

* :doc:`../engines/neural_networks` - Neural network documentation
* :doc:`../engines/attention_mechanisms` - Attention mechanisms

