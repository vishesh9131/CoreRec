Configuration Manager
=====================

The Configuration Manager handles model configurations, hyperparameters, and experiment settings.

Overview
--------

.. automodule:: corerec.config.config_manager
   :members:
   :undoc-members:
   :show-inheritance:

Configuration Files
-------------------

CoreRec supports YAML and JSON configuration files:

YAML Example
^^^^^^^^^^^^

.. code-block:: yaml

   # config.yaml
   model:
     type: MatrixFactorization
     params:
       n_factors: 50
       learning_rate: 0.01
       regularization: 0.001
   
   training:
     epochs: 20
     batch_size: 256
     validation_split: 0.2
     early_stopping_patience: 5
   
   evaluation:
     metrics:
       - precision@10
       - recall@10
       - ndcg@10
   
   data:
     train_path: data/train.csv
     test_path: data/test.csv
     preprocessing:
       min_user_interactions: 5
       min_item_interactions: 5

JSON Example
^^^^^^^^^^^^

.. code-block:: json

   {
     "model": {
       "type": "DeepFM",
       "params": {
         "embed_dim": 32,
         "mlp_dims": [128, 64, 32],
         "dropout": 0.2
       }
     },
     "training": {
       "epochs": 10,
       "batch_size": 32,
       "learning_rate": 0.001
     }
   }

Usage
-----

Loading Configuration
^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.config import ConfigManager
   
   # Load from file
   config = ConfigManager.load('config.yaml')
   
   # Access configuration
   print(config.model.type)
   print(config.model.params.n_factors)
   print(config.training.epochs)

Creating Configuration
^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.config import ConfigManager, ModelConfig, TrainingConfig
   
   # Create configuration programmatically
   config = ConfigManager(
       model=ModelConfig(
           type='MatrixFactorization',
           params={'n_factors': 50, 'learning_rate': 0.01}
       ),
       training=TrainingConfig(
           epochs=20,
           batch_size=256
       )
   )
   
   # Save configuration
   config.save('my_config.yaml')

Using Configuration
^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.config import ConfigManager
   from corerec.engines.unionizedFilterEngine import MatrixFactorization
   
   # Load config
   config = ConfigManager.load('config.yaml')
   
   # Initialize model from config
   model = MatrixFactorization(**config.model.params)
   
   # Train with config
   model.fit(
       train_data,
       epochs=config.training.epochs,
       batch_size=config.training.batch_size
   )

Configuration Validation
------------------------

.. code-block:: python

   from corerec.config import ConfigValidator
   
   # Validate configuration
   validator = ConfigValidator()
   
   try:
       validator.validate(config)
       print("Configuration is valid")
   except ValueError as e:
       print(f"Invalid configuration: {e}")

Environment Variables
---------------------

Override configuration with environment variables:

.. code-block:: bash

   export COREREC_MODEL_TYPE=DeepFM
   export COREREC_LEARNING_RATE=0.001
   export COREREC_BATCH_SIZE=64

.. code-block:: python

   from corerec.config import ConfigManager
   
   # Load with environment overrides
   config = ConfigManager.load('config.yaml', use_env=True)

Experiment Tracking
-------------------

Track multiple experiments:

.. code-block:: python

   from corerec.config import ExperimentTracker
   
   tracker = ExperimentTracker('experiments/')
   
   # Start experiment
   exp = tracker.start_experiment('experiment_1', config)
   
   # Train model
   model.fit(train_data)
   
   # Log results
   exp.log_metrics(results)
   
   # End experiment
   exp.end()

Best Practices
--------------

1. **Version your configs**: Keep configs in version control
2. **Use descriptive names**: Name configs clearly (e.g., ``deepfm_baseline.yaml``)
3. **Document parameters**: Add comments explaining parameter choices
4. **Validate before training**: Always validate configs before long training runs
5. **Track experiments**: Use experiment tracking for reproducibility

See Also
--------

* :doc:`../advanced/training` - Advanced training configuration
* :doc:`../examples/overview` - Configuration examples

