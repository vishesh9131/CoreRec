Graph-Based Algorithms
======================

Graph-based recommendation algorithms in CoreRec leverage network structures for recommendations.

Overview
--------

Graph-based methods model users and items as nodes in a graph, using graph structure and propagation for recommendations.

Available Algorithms
--------------------

GNN (Graph Neural Networks)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^

General graph neural network for recommendations.

.. autoclass:: corerec.engines.unionizedFilterEngine.graph_based_base.GNN_base
   :members:
   :show-inheritance:

**Example:**

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.graph_based_base import GNN_base
   
   model = GNN_base(
       embedding_dim=64,
       num_layers=3,
       aggregator='mean',
       dropout=0.1
   )
   
   model.build_graph(interactions)
   model.fit(interactions, epochs=50)
   recommendations = model.recommend(user_id=123, top_k=10)

LightGCN
^^^^^^^^

Lightweight Graph Convolutional Network for collaborative filtering.

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.graph_based_base import lightgcn_base
   
   model = lightgcn_base.LightGCN(
       num_users=1000,
       num_items=5000,
       embedding_dim=64,
       num_layers=3
   )
   
   model.fit(interactions, epochs=100)
   recommendations = model.recommend(user_id=123, top_k=10)

**Key Features:**

* Simplified GCN without feature transformation
* Only neighborhood aggregation
* Very efficient and effective
* State-of-the-art performance

DeepWalk
^^^^^^^^

Random walk based graph embeddings.

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.graph_based_base import DeepWalk_base
   
   model = DeepWalk_base.DeepWalk(
       embedding_dim=128,
       walk_length=80,
       num_walks=10,
       window_size=10
   )
   
   model.fit(graph)
   similar_items = model.get_similar_items(item_id=123, top_k=10)

**Key Features:**

* Random walks on graph
* Skip-gram model for embeddings
* Unsupervised learning
* Captures structural similarity

Node2Vec
^^^^^^^^

Extension of DeepWalk with biased random walks.

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.graph_based_base import Node2Vec_base
   
   model = Node2Vec_base.Node2Vec(
       embedding_dim=128,
       walk_length=80,
       num_walks=10,
       p=1.0,  # Return parameter
       q=1.0   # In-out parameter
   )
   
   model.fit(graph)

**Key Features:**

* Biased random walks (BFS vs DFS)
* Flexible exploration-exploitation trade-off
* Better than DeepWalk for diverse graphs

GraphSAGE
^^^^^^^^^

Graph SAmple and aggreGatE.

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.graph_based_base import GraphSAGE_base
   
   model = GraphSAGE_base.GraphSAGE(
       embedding_dim=64,
       num_layers=2,
       aggregator='mean',  # or 'gcn', 'pool', 'lstm'
       dropout=0.1
   )
   
   model.fit(graph, node_features, epochs=50)

**Key Features:**

* Inductive learning (handles new nodes)
* Multiple aggregators
* Uses node features
* Scalable to large graphs

Use Cases
---------

Social Network Recommendations
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Friend or connection recommendations:

.. code-block:: python

   import pandas as pd
   from corerec.engines.unionizedFilterEngine.graph_based_base import GNN_base
   
   # Social network edges
   friendships = pd.DataFrame({
       'user_a': [...],
       'user_b': [...],
       'weight': [...]  # Interaction strength
   })
   
   # Build and train model
   model = GNN_base(embedding_dim=128)
   model.build_graph(friendships)
   model.fit(friendships, epochs=100)
   
   # Recommend friends for user
   friend_recommendations = model.recommend(user_id=123, top_k=10)

Item-to-Item Recommendations
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Product recommendations based on co-purchase graph:

.. code-block:: python

   # Co-purchase data
   copurchases = pd.DataFrame({
       'item_a': [...],
       'item_b': [...],
       'count': [...]  # Co-purchase count
   })
   
   # Train DeepWalk
   from corerec.engines.unionizedFilterEngine.graph_based_base import DeepWalk_base
   
   model = DeepWalk_base.DeepWalk(embedding_dim=128)
   model.fit(copurchases)
   
   # Get similar products
   similar_products = model.get_similar_items(item_id=456, top_k=5)

Heterogeneous Graphs
^^^^^^^^^^^^^^^^^^^^^

Multi-type nodes and edges:

.. code-block:: python

   # User-item-category heterogeneous graph
   edges = pd.DataFrame({
       'source': [...],
       'target': [...],
       'edge_type': ['user-item', 'item-category', ...],
       'weight': [...]
   })
   
   model = GNN_base(embedding_dim=64)
   model.build_heterogeneous_graph(edges)
   model.fit(edges, epochs=50)

Knowledge Graph Embeddings
^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   # Knowledge graph triples
   kg_triples = pd.DataFrame({
       'head': [...],
       'relation': [...],
       'tail': [...]
   })
   
   from corerec.engines.unionizedFilterEngine.graph_based_base import KGE_base
   
   model = KGE_base.KnowledgeGraphEmbedding(
       embedding_dim=100,
       num_entities=10000,
       num_relations=50
   )
   
   model.fit(kg_triples, epochs=100)

Advanced Features
-----------------

Graph Construction
^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.graph_based_base import GraphBuilder
   
   builder = GraphBuilder()
   
   # Build from interactions
   graph = builder.from_interactions(
       interactions,
       user_col='user_id',
       item_col='item_id',
       weight_col='rating'
   )
   
   # Add item similarity edges
   graph = builder.add_similarity_edges(
       graph,
       item_features,
       method='cosine',
       threshold=0.7
   )

Graph Sampling
^^^^^^^^^^^^^^

For large graphs, use sampling:

.. code-block:: python

   # Sample subgraph for mini-batch training
   sampler = model.get_sampler(
       method='random_walk',  # or 'neighborhood', 'frontier'
       num_samples=1000
   )
   
   for epoch in range(num_epochs):
       for batch in sampler:
           model.train_on_batch(batch)

Multi-Hop Aggregation
^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   model = GNN_base(
       embedding_dim=64,
       num_layers=3,  # 3-hop aggregation
       aggregator='mean'
   )
   
   # Each layer aggregates from neighbors
   # Layer 1: direct neighbors
   # Layer 2: 2-hop neighbors
   # Layer 3: 3-hop neighbors

Attention Mechanisms
^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.graph_based_base import GAT_base
   
   # Graph Attention Networks
   model = GAT_base.GAT(
       embedding_dim=64,
       num_heads=4,  # Multi-head attention
       num_layers=2,
       dropout=0.2
   )
   
   model.fit(graph, epochs=50)

Performance Optimization
------------------------

GPU Acceleration
^^^^^^^^^^^^^^^^

.. code-block:: python

   model = GNN_base(
       embedding_dim=64,
       device='cuda'  # Use GPU
   )

Neighbor Sampling
^^^^^^^^^^^^^^^^^

For large graphs:

.. code-block:: python

   model = GraphSAGE_base.GraphSAGE(
       embedding_dim=64,
       neighbor_samples=[25, 10]  # Sample 25 1-hop, 10 2-hop neighbors
   )

Precomputed Embeddings
^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   # Precompute embeddings
   user_embeddings = model.get_user_embeddings()
   item_embeddings = model.get_item_embeddings()
   
   # Save for fast inference
   model.save_embeddings('embeddings.npz')
   
   # Load and use
   embeddings = model.load_embeddings('embeddings.npz')

Best Practices
--------------

1. **Graph Construction**
   
   * Choose appropriate edge types
   * Filter noisy edges
   * Normalize edge weights
   * Consider directed vs undirected

2. **Model Selection**
   
   * LightGCN: Best for bipartite user-item graphs
   * DeepWalk/Node2Vec: Good for homogeneous graphs
   * GraphSAGE: Best when you have node features
   * GAT: When edge importance varies

3. **Training**
   
   * Use mini-batch training for large graphs
   * Implement neighbor sampling
   * Monitor over-smoothing (too many layers)
   * Use early stopping

4. **Evaluation**
   
   * Test on unseen edges
   * Check embedding quality
   * Evaluate link prediction
   * Measure recommendation quality

5. **Deployment**
   
   * Precompute embeddings
   * Use approximate nearest neighbor search
   * Implement caching
   * Update incrementally

Common Challenges
-----------------

Over-smoothing
^^^^^^^^^^^^^^

**Problem:** Too many layers make all embeddings similar

**Solutions:**

* Use fewer layers (2-3 typically sufficient)
* Add skip connections
* Use JK-Net (Jumping Knowledge Networks)

Scalability
^^^^^^^^^^^

**Problem:** Large graphs don't fit in memory

**Solutions:**

* Mini-batch training with sampling
* Use distributed graph processing
* Implement graph partitioning
* Precompute and cache embeddings

Cold Start
^^^^^^^^^^

**Problem:** New users/items with no connections

**Solutions:**

* Use node features (GraphSAGE)
* Implement content-based fallback
* Use meta-learning
* Ask for initial preferences

See Also
--------

* :doc:`../algorithms/graph_based` - Algorithm details
* :doc:`../examples/overview` - Usage examples
* :doc:`../advanced/training` - Advanced training

