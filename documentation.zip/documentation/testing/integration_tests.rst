Integration Tests
=================

Integration tests verify that components work together correctly.

End-to-End Tests
----------------

Complete workflow tests:

.. code-block:: python

   # tests/test_integration.py
   def test_complete_recommendation_workflow():
       """Test data loading, training, evaluation"""
       from corerec.preprocessing import DataPreprocessor
       from corerec.engines.unionizedFilterEngine import MatrixFactorization
       from corerec.evaluation import Evaluator
       
       # Load and preprocess
       preprocessor = DataPreprocessor()
       data = preprocessor.fit_transform(raw_data)
       
       # Split
       train, test = train_test_split(data)
       
       # Train
       model = MatrixFactorization()
       model.fit(train)
       
       # Evaluate
       evaluator = Evaluator()
       results = evaluator.evaluate(model, test)
       
       assert 'precision@10' in results
       assert results['precision@10'] > 0

Pipeline Tests
--------------

Test recommendation pipelines:

.. code-block:: python

   def test_recommendation_pipeline():
       """Test complete pipeline"""
       from corerec.pipelines import RecommendationPipeline
       
       pipeline = RecommendationPipeline(
           preprocessor=preprocessor,
           model=model,
           postprocessor=postprocessor
       )
       
       pipeline.fit(train_data)
       recommendations = pipeline.recommend(user_id=123)
       
       assert len(recommendations) > 0

Running Integration Tests
--------------------------

.. code-block:: bash

   # Run integration tests
   pytest tests/test_integration.py -v
   
   # With markers
   pytest tests/ -m integration

See Also
--------

* :doc:`overview` - Testing overview
* :doc:`unit_tests` - Unit tests

