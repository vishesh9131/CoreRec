Neural Network Algorithms
=========================

Deep learning algorithms for recommendations.

DeepFM
------

Deep Factorization Machines.

See Also
--------

* :doc:`../engines/neural_networks` - Neural network engine
* :doc:`../examples/neural_network_examples` - Examples

