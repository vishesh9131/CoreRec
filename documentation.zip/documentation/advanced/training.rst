Advanced Training
=================

Advanced training techniques for recommendation models.

Distributed Training
--------------------

Train models across multiple GPUs or machines:

.. code-block:: python

   from corerec.async_ddp import DistributedTrainer
   
   trainer = DistributedTrainer(
       model=model,
       world_size=4,
       backend='nccl'
   )
   
   trainer.fit(data, epochs=10)

Hyperparameter Tuning
----------------------

.. code-block:: python

   from corerec.hyper_train import HyperparameterTuner
   
   tuner = HyperparameterTuner(
       model_class=MatrixFactorization,
       param_grid=param_grid,
       cv=5
   )
   
   best_params = tuner.fit(data)

See Also
--------

* :doc:`../engines/overview` - Engine documentation
* :doc:`evaluation` - Model evaluation

