API Overview
============

CoreRec provides a clean and intuitive API for building recommendation systems. The API is organized into several key components:

Core Interfaces
---------------

Base Recommender
^^^^^^^^^^^^^^^^

All recommendation models inherit from the base recommender interface, providing consistent methods:

.. code-block:: python

   from corerec.api.base_recommender import BaseRecommender
   
   class MyRecommender(BaseRecommender):
       def fit(self, data):
           """Train the model"""
           pass
       
       def recommend(self, user_id, top_k=10):
           """Get top-k recommendations"""
           pass
       
       def predict(self, user_id, item_id):
           """Predict score for user-item pair"""
           pass

Key Methods
^^^^^^^^^^^

All recommenders implement these core methods:

* ``fit(data)`` - Train the model on data
* ``recommend(user_id, top_k)`` - Generate top-k recommendations
* ``predict(user_id, item_id)`` - Predict score for a user-item pair
* ``save(path)`` - Save model to disk
* ``load(path)`` - Load model from disk

API Modules
-----------

.. toctree::
   :maxdepth: 2
   
   base_recommender
   model_interface
   predictor_interface
   config_manager

Model Interface
^^^^^^^^^^^^^^^

The model interface provides methods for model lifecycle management:

.. automodule:: corerec.api.model_interface
   :members:
   :undoc-members:
   :show-inheritance:

Configuration Management
^^^^^^^^^^^^^^^^^^^^^^^^

Manage model configurations and hyperparameters:

.. automodule:: corerec.config.config_manager
   :members:
   :undoc-members:
   :show-inheritance:

Usage Examples
--------------

Basic Usage
^^^^^^^^^^^

.. code-block:: python

   from corerec.engines.unionizedFilterEngine import MatrixFactorization
   import pandas as pd
   
   # Load data
   data = pd.read_csv('ratings.csv')
   
   # Initialize model
   model = MatrixFactorization(n_factors=50, learning_rate=0.01)
   
   # Train
   model.fit(data)
   
   # Recommend
   recommendations = model.recommend(user_id=123, top_k=10)
   
   # Predict
   score = model.predict(user_id=123, item_id=456)
   
   # Save
   model.save('my_model.pkl')

Advanced Usage
^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.api import BaseRecommender
   from corerec.config import ConfigManager
   
   # Load configuration
   config = ConfigManager.load('config.yaml')
   
   # Initialize model with config
   model = MatrixFactorization(**config.model_params)
   
   # Train with custom parameters
   model.fit(
       data,
       epochs=config.training.epochs,
       batch_size=config.training.batch_size,
       validation_split=0.2
   )
   
   # Evaluate
   from corerec.evaluation import Evaluator
   evaluator = Evaluator(metrics=config.evaluation.metrics)
   results = evaluator.evaluate(model, test_data)

API Design Principles
---------------------

1. **Consistency**: All models follow the same interface
2. **Simplicity**: Easy to use for common cases
3. **Flexibility**: Extensible for advanced use cases
4. **Type Safety**: Clear type hints throughout
5. **Documentation**: Comprehensive docstrings

Creating Custom Models
----------------------

To create a custom recommendation model:

.. code-block:: python

   from corerec.api.base_recommender import BaseRecommender
   import numpy as np
   
   class MyCustomRecommender(BaseRecommender):
       def __init__(self, param1=10, param2=0.01):
           super().__init__()
           self.param1 = param1
           self.param2 = param2
           self.user_factors = None
           self.item_factors = None
       
       def fit(self, data):
           """Train the model"""
           n_users = data['user_id'].nunique()
           n_items = data['item_id'].nunique()
           
           # Initialize factors
           self.user_factors = np.random.randn(n_users, self.param1)
           self.item_factors = np.random.randn(n_items, self.param1)
           
           # Your training logic here
           for epoch in range(100):
               # Training code
               pass
           
           return self
       
       def recommend(self, user_id, top_k=10):
           """Generate recommendations"""
           if self.user_factors is None:
               raise ValueError("Model not trained. Call fit() first.")
           
           # Compute scores
           user_vec = self.user_factors[user_id]
           scores = self.item_factors @ user_vec
           
           # Get top-k
           top_indices = np.argsort(scores)[-top_k:][::-1]
           
           return [(idx, scores[idx]) for idx in top_indices]
       
       def predict(self, user_id, item_id):
           """Predict score"""
           user_vec = self.user_factors[user_id]
           item_vec = self.item_factors[item_id]
           return np.dot(user_vec, item_vec)

Next Steps
----------

* Read detailed :doc:`base_recommender` documentation
* Explore :doc:`model_interface` for advanced features
* Check :doc:`config_manager` for configuration options
* See :doc:`../examples/overview` for practical examples

