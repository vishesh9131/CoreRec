Unionized Filter Examples
=========================

Examples demonstrating collaborative filtering algorithms.

Matrix Factorization
--------------------

.. code-block:: python

   from corerec.engines.unionizedFilterEngine import MatrixFactorization
   import pandas as pd
   
   # User-item ratings
   ratings = pd.DataFrame({
       'user_id': [1, 1, 1, 2, 2, 2, 3, 3, 3],
       'item_id': [101, 102, 103, 101, 104, 105, 102, 103, 106],
       'rating': [5, 4, 3, 4, 5, 3, 5, 4, 2]
   })
   
   # Train model
   model = MatrixFactorization(n_factors=20, learning_rate=0.01, n_epochs=20)
   model.fit(ratings)
   
   # Get recommendations
   recommendations = model.recommend(user_id=1, top_k=5)
   print("Recommendations for user 1:", recommendations)
   
   # Predict specific rating
   predicted_rating = model.predict(user_id=1, item_id=104)
   print(f"Predicted rating: {predicted_rating:.2f}")

ALS Recommender
---------------

.. code-block:: python

   from corerec.engines.unionizedFilterEngine import ALSRecommender
   
   # For implicit feedback
   implicit_data = pd.DataFrame({
       'user_id': [...],
       'item_id': [...],
       'confidence': [...]  # Number of interactions
   })
   
   model = ALSRecommender(factors=50, regularization=0.01, iterations=15, alpha=40)
   model.fit(implicit_data)
   
   recommendations = model.recommend(user_id=123, top_k=10)

Running Examples
----------------

.. code-block:: bash

   # Various unionized filter examples
   python examples/unionized_fast_example.py
   python examples/unionized_sar_example.py
   python examples/unionized_rbm_example.py
   python examples/unionized_rlrmc_example.py
   python examples/unionized_geomlc_example.py

See Also
--------

* :doc:`../engines/unionized_filter` - Unionized filter documentation
* :doc:`../engines/matrix_factorization` - Matrix factorization details

