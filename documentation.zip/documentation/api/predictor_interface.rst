Predictor Interface
===================

The Predictor Interface provides a standardized way to make predictions with trained recommendation models.

Overview
--------

.. automodule:: corerec.api.predictor_interface
   :members:
   :undoc-members:
   :show-inheritance:

Key Features
------------

* Single prediction
* Batch prediction
* Real-time inference
* Caching mechanisms
* Fallback strategies

Basic Usage
-----------

.. code-block:: python

   from corerec.api.predictor_interface import Predictor
   
   # Load model
   predictor = Predictor.from_model('my_model.pkl')
   
   # Single prediction
   score = predictor.predict(user_id=123, item_id=456)
   
   # Batch prediction
   scores = predictor.predict_batch([
       (123, 456),
       (123, 789),
       (124, 456)
   ])

Advanced Features
-----------------

Caching
^^^^^^^

.. code-block:: python

   predictor = Predictor.from_model(
       'my_model.pkl',
       cache_size=1000,  # Cache top 1000 predictions
       cache_ttl=3600    # Cache TTL in seconds
   )

Fallback Strategies
^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   predictor = Predictor.from_model(
       'my_model.pkl',
       fallback='popularity'  # Use popularity for unknown users/items
   )

Real-time Inference
^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   # Optimized for real-time serving
   predictor = Predictor.from_model(
       'my_model.pkl',
       optimization='speed',  # Optimize for speed
       batch_size=32
   )

See Also
--------

* :doc:`base_recommender` - Base recommender API
* :doc:`model_interface` - Model lifecycle management
* :doc:`../advanced/serving` - Model serving

