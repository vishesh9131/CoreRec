Model Interface
===============

The Model Interface module provides utilities for model lifecycle management, including training, evaluation, and deployment.

Overview
--------

CoreRec's model interface standardizes how models are created, trained, evaluated, and deployed.

.. automodule:: corerec.api.model_interface
   :members:
   :undoc-members:
   :show-inheritance:

Key Components
--------------

ModelInterface Class
^^^^^^^^^^^^^^^^^^^^

Base interface for all models:

.. code-block:: python

   from corerec.api.model_interface import ModelInterface
   
   class MyModel(ModelInterface):
       def train(self, data):
           """Training logic"""
           pass
       
       def evaluate(self, test_data):
           """Evaluation logic"""
           pass
       
       def deploy(self):
           """Deployment logic"""
           pass

Training Interface
^^^^^^^^^^^^^^^^^^

Methods for model training:

* ``train(data, **kwargs)`` - Train model on data
* ``validate(val_data)`` - Validate during training
* ``early_stopping(patience)`` - Early stopping mechanism
* ``checkpoint(path)`` - Save training checkpoints

Example:

.. code-block:: python

   from corerec.api.model_interface import ModelInterface
   
   model = MyModel()
   
   # Train with validation and early stopping
   model.train(
       train_data,
       validation_data=val_data,
       early_stopping_patience=5,
       checkpoint_path='checkpoints/'
   )

Evaluation Interface
^^^^^^^^^^^^^^^^^^^^

Methods for model evaluation:

* ``evaluate(test_data, metrics)`` - Evaluate on test data
* ``cross_validate(data, cv)`` - Cross-validation
* ``score(predictions, targets)`` - Compute scores

Example:

.. code-block:: python

   from corerec.evaluation import Evaluator
   
   # Evaluate with multiple metrics
   results = model.evaluate(
       test_data,
       metrics=['precision@10', 'recall@10', 'ndcg@10']
   )
   
   print(f"Precision@10: {results['precision@10']:.4f}")
   print(f"Recall@10: {results['recall@10']:.4f}")
   print(f"NDCG@10: {results['ndcg@10']:.4f}")

Deployment Interface
^^^^^^^^^^^^^^^^^^^^

Methods for model deployment:

* ``export(path, format)`` - Export model
* ``serve(host, port)`` - Serve model
* ``batch_predict(data)`` - Batch prediction

Example:

.. code-block:: python

   # Export model
   model.export('model.onnx', format='onnx')
   
   # Serve model
   model.serve(host='0.0.0.0', port=8000)
   
   # Batch prediction
   predictions = model.batch_predict(batch_data)

See Also
--------

* :doc:`base_recommender` - Base recommender API
* :doc:`predictor_interface` - Prediction interface
* :doc:`../advanced/training` - Advanced training techniques

