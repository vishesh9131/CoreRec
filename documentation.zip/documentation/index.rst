.. CoreRec documentation master file

Welcome to CoreRec's Documentation!
====================================

.. image:: https://static.pepy.tech/badge/corerec
   :target: https://pepy.tech/project/corerec
   :alt: Downloads

.. image:: https://img.shields.io/github/commit-activity/m/vishesh9131/corerec
   :alt: GitHub commit activity

.. image:: https://img.shields.io/pypi/dm/corerec?label=PyPi%20Downloads
   :alt: PyPI - Downloads

**CoreRec** is a comprehensive recommendation engine library for building advanced recommendation systems. 
It provides state-of-the-art algorithms including collaborative filtering, content-based filtering, 
neural network-based models, graph-based algorithms, and hybrid approaches.

CoreRec is designed for:

* **Researchers** - Experiment with cutting-edge recommendation algorithms
* **Data Scientists** - Build production-ready recommendation systems
* **Developers** - Integrate recommendations into applications easily
* **Students** - Learn recommendation system concepts with practical examples

.. note:: 
   CoreRec is trusted by over 30000+ users and receives 1.5k+ downloads per month on PyPI.

Quick Start
-----------

Installation
^^^^^^^^^^^^

Install CoreRec using pip:

.. code-block:: bash

   pip install --upgrade corerec

Basic Usage
^^^^^^^^^^^

.. code-block:: python

   from corerec.engines.contentFilterEngine import TFIDFRecommender
   
   # Initialize recommender
   recommender = TFIDFRecommender()
   
   # Fit and recommend
   recommender.fit(data)
   recommendations = recommender.recommend(user_id, top_k=10)

Documentation Contents
---------------------

.. toctree::
   :maxdepth: 2
   :caption: Getting Started
   
   getting_started
   installation
   quickstart

.. toctree::
   :maxdepth: 2
   :caption: Core API
   
   api/overview
   api/base_recommender
   api/model_interface
   api/predictor_interface
   api/config_manager

.. toctree::
   :maxdepth: 2
   :caption: Engines
   
   engines/overview
   engines/content_filter
   engines/unionized_filter
   engines/neural_networks
   engines/graph_based
   engines/matrix_factorization
   engines/attention_mechanisms

.. toctree::
   :maxdepth: 2
   :caption: Algorithm Categories
   
   algorithms/content_based
   algorithms/collaborative_filtering
   algorithms/neural_networks
   algorithms/graph_based
   algorithms/hybrid_methods
   algorithms/deep_learning

.. toctree::
   :maxdepth: 2
   :caption: Advanced Features
   
   advanced/training
   advanced/evaluation
   advanced/serialization
   advanced/serving
   advanced/pipelines
   advanced/integrations

.. toctree::
   :maxdepth: 2
   :caption: Examples & Tutorials
   
   examples/overview
   examples/content_filter_examples
   examples/unionized_filter_examples
   examples/neural_network_examples
   examples/real_world_examples

.. toctree::
   :maxdepth: 2
   :caption: Testing
   
   testing/overview
   testing/unit_tests
   testing/integration_tests
   testing/smoke_tests

.. toctree::
   :maxdepth: 2
   :caption: Reference Documentation
   
   reference/modules
   reference/utilities
   reference/preprocessing
   reference/metrics
   
.. toctree::
   :maxdepth: 1
   :caption: Legacy Documentation
   
   base_recommender
   context_personalization
   cr_contentFilterFactory
   embedding_representation_learning
   fairness_explainability
   graph_based_algorithms
   hybrid_ensemble_methods
   learning_paradigms
   miscellaneous_techniques
   multi_modal_cross_domain_methods
   nn_based_algorithms
   other_approaches
   performance_scalability
   probabilistic_statistical_methods
   special_techniques
   tfidf_recommender
   traditional_ml_algorithms

Key Features
------------

🎯 **Multiple Recommendation Strategies**

* Content-Based Filtering (TF-IDF, Neural Networks)
* Collaborative Filtering (Matrix Factorization, ALS, SVD)
* Deep Learning Models (DeepFM, DCN, DIN, DIEN, Wide & Deep)
* Graph-Based Algorithms (GNN, LightGCN, DeepWalk)
* Attention Mechanisms (SASRec, Transformer-based)
* Hybrid & Ensemble Methods

🚀 **Production Ready**

* Model Serialization & Deserialization
* Model Serving Infrastructure
* Training Pipelines
* Evaluation Metrics
* Integration Utilities

📊 **Rich Utilities**

* Data Preprocessing
* Feature Engineering
* Visualization Tools
* Performance Optimization
* Custom Loss Functions & Optimizers

Community and Support
---------------------

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **GitHub Repository**
     - https://github.com/vishesh9131/corerec
   * - **Website**
     - https://corerec.tech
   * - **PyPI**
     - https://pypi.org/project/corerec/
   * - **Author**
     - Vishesh Yadav (vishesh@corerec.tech)
   * - **License**
     - Research & Educational Use

Contributing
------------

We welcome contributions! Please see our GitHub repository for:

* Bug reports and feature requests
* Code contributions
* Documentation improvements
* Example notebooks and tutorials

Indices and Tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
