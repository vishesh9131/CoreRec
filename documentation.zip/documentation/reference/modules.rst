Module Reference
================

Complete reference for all CoreRec modules.

Core Modules
------------

The core modules provide essential functionality:

* ``corerec.api`` - Core API interfaces
* ``corerec.config`` - Configuration management
* ``corerec.engines`` - Recommendation engines
* ``corerec.evaluation`` - Model evaluation
* ``corerec.preprocessing`` - Data preprocessing
* ``corerec.training`` - Training utilities
* ``corerec.serving`` - Model serving
* ``corerec.pipelines`` - Production pipelines
* ``corerec.serialization`` - Model serialization
* ``corerec.integrations`` - Third-party integrations

Engine Modules
--------------

ContentFilterEngine
^^^^^^^^^^^^^^^^^^^

Content-based filtering engines:

* ``corerec.engines.contentFilterEngine`` - Main module
* ``corerec.engines.contentFilterEngine.tfidf_recommender`` - TF-IDF recommender
* ``corerec.engines.contentFilterEngine.base_recommender`` - Base classes

UnionizedFilterEngine
^^^^^^^^^^^^^^^^^^^^^

Collaborative filtering engines:

* ``corerec.engines.unionizedFilterEngine`` - Main module
* ``corerec.engines.unionizedFilterEngine.matrix_factorization`` - Matrix factorization
* ``corerec.engines.unionizedFilterEngine.als_recommender`` - ALS recommender

Utility Modules
---------------

Utility and helper modules:

* ``corerec.utils`` - General utilities
* ``corerec.cr_utility`` - Core utilities
* ``corerec.metrics`` - Evaluation metrics
* ``corerec.visualization`` - Visualization tools

See Also
--------

* :doc:`../api/overview` - API documentation
* :doc:`../engines/overview` - Engine documentation
* :doc:`utilities` - Utility documentation

