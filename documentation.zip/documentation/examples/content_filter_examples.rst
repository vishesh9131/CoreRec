Content Filter Examples
=======================

Examples demonstrating content-based filtering in CoreRec.

TF-IDF Recommender
------------------

Basic Example
^^^^^^^^^^^^^

.. code-block:: python

   from corerec.engines.contentFilterEngine import TFIDFRecommender
   import pandas as pd
   
   # Movie descriptions
   movies = pd.DataFrame({
       'movie_id': [1, 2, 3, 4, 5],
       'title': ['The Matrix', 'Inception', 'The Notebook', 'Interstellar', 'Titanic'],
       'description': [
           'A hacker discovers the true nature of reality',
           'A thief steals secrets through dream technology',
           'A romantic story about a couple in love',
           'Astronauts travel through a wormhole',
           'Romance on a doomed ocean liner'
       ],
       'genre': ['Sci-Fi', 'Sci-Fi', 'Romance', 'Sci-Fi', 'Romance']
   })
   
   # Initialize and train
   recommender = TFIDFRecommender()
   recommender.fit(movies, text_column='description')
   
   # Find similar movies
   print("Movies similar to 'The Matrix':")
   similar = recommender.recommend(item_id=1, top_k=3)
   
   for movie_id, score in similar:
       movie = movies[movies['movie_id'] == movie_id].iloc[0]
       print(f"  {movie['title']}: {score:.3f}")

Advanced TF-IDF
^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.engines.contentFilterEngine import TFIDFRecommender
   from sklearn.feature_extraction.text import TfidfVectorizer
   
   # Custom TF-IDF parameters
   custom_vectorizer = TfidfVectorizer(
       max_features=1000,
       ngram_range=(1, 2),
       min_df=2,
       max_df=0.8,
       stop_words='english'
   )
   
   recommender = TFIDFRecommender(vectorizer=custom_vectorizer)
   recommender.fit(movies, text_column='description')

Running Examples
----------------

From Repository
^^^^^^^^^^^^^^^

.. code-block:: bash

   # Basic TF-IDF example
   cd examples
   python content_filter_tfidf_example.py
   
   # Quickstart example
   python content_filter_quickstart.py

See Also
--------

* :doc:`../engines/content_filter` - Content filter documentation
* :doc:`unionized_filter_examples` - Collaborative filtering examples
* :doc:`overview` - All examples

