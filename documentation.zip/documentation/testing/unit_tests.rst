Unit Tests
==========

Unit tests verify individual components work correctly in isolation.

Content Filter Unit Tests
--------------------------

Located in ``tests/contentFilterEngine/``

TF-IDF Recommender Tests
^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   # tests/contentFilterEngine/test_tfidf.py
   import pytest
   from corerec.engines.contentFilterEngine import TFIDFRecommender
   
   def test_tfidf_initialization():
       recommender = TFIDFRecommender()
       assert recommender is not None
   
   def test_tfidf_fit():
       recommender = TFIDFRecommender()
       recommender.fit(sample_items, text_column='description')
       assert recommender.is_fitted
   
   def test_tfidf_recommend():
       recommender = TFIDFRecommender()
       recommender.fit(sample_items, text_column='description')
       recs = recommender.recommend(item_id=1, top_k=3)
       assert len(recs) == 3

Unionized Filter Unit Tests
----------------------------

Located in ``tests/unionizedFilterEngine/``

Matrix Factorization Tests
^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   # Run tests
   pytest tests/unionizedFilterEngine/test_matrix_factorization.py -v

Neural Network Tests
^^^^^^^^^^^^^^^^^^^^

.. code-block:: bash

   # DeepFM tests
   pytest tests/test_FM_base.py
   pytest tests/test_FFM_base.py
   pytest tests/test_FGCNN_base.py
   
   # DCN tests
   pytest tests/unionizedFilterEngine/nn_base/test_dcn.py
   
   # DIN/DIEN tests
   pytest tests/unionizedFilterEngine/nn_base/test_din.py

Graph-Based Tests
^^^^^^^^^^^^^^^^^

.. code-block:: bash

   # GNN tests
   pytest tests/test_GNN_base.py
   
   # Other graph tests
   pytest tests/unionizedFilterEngine/graph_based_base/

Running Unit Tests
------------------

.. code-block:: bash

   # All unit tests
   pytest tests/ -v
   
   # Specific category
   pytest tests/contentFilterEngine/ -v
   pytest tests/unionizedFilterEngine/ -v
   
   # With coverage
   pytest tests/ --cov=corerec

See Also
--------

* :doc:`overview` - Testing overview
* :doc:`integration_tests` - Integration tests

