fairness\_explainability package
================================

Submodules
----------

fairness\_explainability.explainable module
-------------------------------------------

.. automodule:: fairness_explainability.explainable
   :members:
   :undoc-members:
   :show-inheritance:

fairness\_explainability.fairness\_aware module
-----------------------------------------------

.. automodule:: fairness_explainability.fairness_aware
   :members:
   :undoc-members:
   :show-inheritance:

fairness\_explainability.privacy\_preserving module
---------------------------------------------------

.. automodule:: fairness_explainability.privacy_preserving
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: fairness_explainability
   :members:
   :undoc-members:
   :show-inheritance:
