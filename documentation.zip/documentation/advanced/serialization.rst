Model Serialization
===================

Save and load models for deployment.

Saving Models
-------------

.. code-block:: python

   # Save model
   model.save('my_model.pkl')
   
   # Save with metadata
   model.save('my_model.pkl', metadata={
       'version': '1.0',
       'training_date': '2024-01-01',
       'metrics': results
   })

Loading Models
--------------

.. code-block:: python

   # Load model
   from corerec.engines.unionizedFilterEngine import MatrixFactorization
   
   model = MatrixFactorization.load('my_model.pkl')

See Also
--------

* :doc:`serving` - Model serving
* :doc:`../api/overview` - API documentation

