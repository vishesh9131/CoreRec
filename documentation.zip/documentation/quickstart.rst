Quickstart Guide
================

This quickstart guide will walk you through building your first recommendation system with CoreRec in just a few minutes.

5-Minute Quickstart
-------------------

Let's build a simple movie recommendation system:

.. code-block:: python

   import pandas as pd
   from corerec.engines.unionizedFilterEngine import MatrixFactorization
   
   # Step 1: Prepare your data
   ratings = pd.DataFrame({
       'user_id': [1, 1, 1, 2, 2, 3, 3, 3, 4, 4],
       'movie_id': [101, 102, 103, 101, 104, 102, 103, 105, 101, 102],
       'rating': [5, 4, 3, 4, 5, 5, 4, 3, 2, 4]
   })
   
   # Step 2: Create and train model
   model = MatrixFactorization(n_factors=10)
   model.fit(ratings)
   
   # Step 3: Get recommendations
   recommendations = model.recommend(user_id=1, top_k=5)
   
   print(f"Recommendations for user 1: {recommendations}")

That's it! You've built your first recommender system.

Complete Examples
-----------------

Example 1: Content-Based Movie Recommender
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

This example shows content-based filtering using movie descriptions:

.. code-block:: python

   import pandas as pd
   from corerec.engines.contentFilterEngine import TFIDFRecommender
   
   # Movie data with descriptions
   movies = pd.DataFrame({
       'movie_id': [1, 2, 3, 4, 5],
       'title': [
           'The Matrix',
           'Inception',
           'The Notebook',
           'Interstellar',
           'Titanic'
       ],
       'description': [
           'A computer hacker learns about the true nature of reality',
           'A thief who steals secrets through dream-sharing technology',
           'A romantic story about a couple who fall in love',
           'Explorers travel through a wormhole in space',
           'A romance between a poor artist and a rich young woman'
       ],
       'genre': [
           'Sci-Fi|Action',
           'Sci-Fi|Thriller',
           'Romance|Drama',
           'Sci-Fi|Drama',
           'Romance|Drama'
       ]
   })
   
   # Initialize recommender
   recommender = TFIDFRecommender()
   recommender.fit(movies, text_column='description')
   
   # Find movies similar to "The Matrix"
   similar_movies = recommender.recommend(item_id=1, top_k=3)
   
   print("Movies similar to 'The Matrix':")
   for movie_id, score in similar_movies:
       movie_info = movies[movies['movie_id'] == movie_id].iloc[0]
       print(f"  {movie_info['title']} (score: {score:.3f})")

Expected output:

.. code-block:: text

   Movies similar to 'The Matrix':
     Inception (score: 0.845)
     Interstellar (score: 0.623)
     The Notebook (score: 0.234)

Example 2: Collaborative Filtering with ALS
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Using Alternating Least Squares for collaborative filtering:

.. code-block:: python

   import pandas as pd
   from corerec.engines.unionizedFilterEngine import ALSRecommender
   
   # Load user-item ratings
   ratings = pd.DataFrame({
       'user_id': [1, 1, 1, 2, 2, 2, 3, 3, 3, 4, 4, 4, 5, 5, 5],
       'item_id': [101, 102, 103, 101, 104, 105, 102, 103, 106, 101, 102, 107, 103, 105, 106],
       'rating': [5, 4, 3, 4, 5, 3, 5, 4, 2, 3, 4, 5, 2, 3, 4]
   })
   
   # Split into train and test
   from sklearn.model_selection import train_test_split
   train_data, test_data = train_test_split(ratings, test_size=0.2, random_state=42)
   
   # Initialize ALS model
   als_model = ALSRecommender(
       factors=50,          # Number of latent factors
       regularization=0.01, # L2 regularization
       iterations=15,       # Number of iterations
       alpha=40            # Confidence weight for implicit feedback
   )
   
   # Train the model
   als_model.fit(train_data)
   
   # Get recommendations for user 1
   recommendations = als_model.recommend(user_id=1, top_k=5)
   
   print("Top 5 recommendations for user 1:")
   for item_id, score in recommendations:
       print(f"  Item {item_id}: {score:.3f}")
   
   # Predict rating for specific user-item pair
   predicted_rating = als_model.predict(user_id=1, item_id=104)
   print(f"\nPredicted rating for user 1, item 104: {predicted_rating:.2f}")

Example 3: Deep Learning with DeepFM
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Using DeepFM for CTR prediction:

.. code-block:: python

   import pandas as pd
   from corerec.engines.unionizedFilterEngine.nn_base import DeepFM_base
   
   # Prepare data with multiple features
   data = pd.DataFrame({
       'user_id': range(1, 101),
       'item_id': [i % 50 + 100 for i in range(100)],
       'user_age': [20 + i % 40 for i in range(100)],
       'user_gender': [i % 2 for i in range(100)],
       'item_category': [i % 10 for i in range(100)],
       'click': [i % 2 for i in range(100)]  # Binary target
   })
   
   # Split data
   from sklearn.model_selection import train_test_split
   train_df, test_df = train_test_split(data, test_size=0.2, random_state=42)
   
   # Define feature dimensions
   feature_dims = {
       'user_id': 1000,
       'item_id': 5000,
       'user_age': 100,
       'user_gender': 2,
       'item_category': 20
   }
   
   # Initialize DeepFM
   deepfm = DeepFM_base(
       feature_dims=feature_dims,
       embed_dim=16,
       mlp_dims=[128, 64, 32],
       dropout=0.2
   )
   
   # Train
   deepfm.fit(
       train_df,
       target_column='click',
       epochs=10,
       batch_size=32,
       learning_rate=0.001
   )
   
   # Evaluate
   from corerec.evaluation import Evaluator
   evaluator = Evaluator(metrics=['auc', 'logloss'])
   results = evaluator.evaluate(deepfm, test_df)
   
   print(f"AUC: {results['auc']:.4f}")
   print(f"LogLoss: {results['logloss']:.4f}")

Example 4: Graph-Based Recommendations
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Using GNN for graph-based recommendations:

.. code-block:: python

   import pandas as pd
   import numpy as np
   from corerec.engines.unionizedFilterEngine.graph_based_base import GNN_base
   
   # Create user-item interaction graph
   interactions = pd.DataFrame({
       'user_id': [1, 1, 2, 2, 3, 3, 4, 4, 5],
       'item_id': [101, 102, 101, 103, 102, 104, 103, 105, 104],
       'weight': [1.0, 0.8, 0.9, 1.0, 0.7, 0.85, 0.95, 0.8, 0.9]
   })
   
   # Initialize GNN model
   gnn_model = GNN_base(
       embedding_dim=64,
       num_layers=3,
       aggregator='mean'
   )
   
   # Build graph and train
   gnn_model.build_graph(interactions)
   gnn_model.fit(interactions, epochs=50)
   
   # Get recommendations
   user_recommendations = gnn_model.recommend(user_id=1, top_k=5)
   
   print("GNN-based recommendations:")
   for item_id, score in user_recommendations:
       print(f"  Item {item_id}: {score:.3f}")

Example 5: Sequential Recommendations with SASRec
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

For sequential/session-based recommendations:

.. code-block:: python

   import pandas as pd
   from corerec.engines.unionizedFilterEngine.attention_mechanism_base import SASRec_base
   
   # User interaction sequences
   sequences = pd.DataFrame({
       'user_id': [1, 1, 1, 1, 2, 2, 2, 3, 3, 3, 3],
       'item_id': [101, 102, 103, 104, 105, 106, 107, 101, 105, 108, 109],
       'timestamp': range(11)
   })
   
   # Initialize SASRec
   sasrec = SASRec_base(
       item_num=200,
       max_len=50,
       hidden_units=64,
       num_blocks=2,
       num_heads=1
   )
   
   # Train on sequences
   sasrec.fit(sequences, epochs=20)
   
   # Predict next items for user 1
   next_items = sasrec.recommend(user_id=1, top_k=5)
   
   print("Next item predictions for user 1:")
   for item_id, score in next_items:
       print(f"  Item {item_id}: {score:.3f}")

Real-World Example: YouTube-Style Recommendations
--------------------------------------------------

Complete example using sample data:

.. code-block:: python

   import pandas as pd
   from corerec.engines.unionizedFilterEngine import FastRecommender
   from corerec.evaluation import Evaluator
   from corerec.preprocessing import DataPreprocessor
   
   # Load sample YouTube data
   # This could be from your database or CSV file
   try:
       from cr_learn.youtube import load
       data = load()
   except:
       # Fallback to sample data
       data = pd.read_csv('sample_data/youtube_demo.csv')
   
   print(f"Loaded {len(data)} interactions")
   
   # Preprocess
   preprocessor = DataPreprocessor()
   data = preprocessor.fit_transform(data)
   
   # Split data chronologically
   split_idx = int(len(data) * 0.8)
   train_data = data[:split_idx]
   test_data = data[split_idx:]
   
   # Initialize recommender
   recommender = FastRecommender(
       embedding_dim=64,
       num_users=data['user_id'].nunique(),
       num_items=data['video_id'].nunique()
   )
   
   # Train
   print("Training model...")
   recommender.fit(
       train_data,
       epochs=10,
       batch_size=256,
       learning_rate=0.001
   )
   
   # Evaluate
   print("Evaluating...")
   evaluator = Evaluator(metrics=['precision@10', 'recall@10', 'ndcg@10'])
   results = evaluator.evaluate(recommender, test_data)
   
   for metric, value in results.items():
       print(f"{metric}: {value:.4f}")
   
   # Get recommendations for a sample user
   sample_user = train_data['user_id'].iloc[0]
   recommendations = recommender.recommend(user_id=sample_user, top_k=10)
   
   print(f"\nTop 10 video recommendations for user {sample_user}:")
   for video_id, score in recommendations:
       print(f"  Video {video_id}: {score:.3f}")

Working with Your Own Data
---------------------------

Loading Data from CSV
^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   import pandas as pd
   
   # Load your ratings data
   ratings = pd.read_csv('your_ratings.csv')
   
   # Ensure correct column names
   ratings.columns = ['user_id', 'item_id', 'rating', 'timestamp']
   
   # Basic preprocessing
   from corerec.preprocessing import DataPreprocessor
   
   preprocessor = DataPreprocessor(
       min_user_interactions=5,  # Filter users with < 5 interactions
       min_item_interactions=5,  # Filter items with < 5 interactions
       encode_ids=True           # Encode IDs to contiguous integers
   )
   
   clean_data = preprocessor.fit_transform(ratings)

Loading Data from Database
^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   import pandas as pd
   import sqlite3
   
   # Connect to database
   conn = sqlite3.connect('your_database.db')
   
   # Query data
   query = """
       SELECT user_id, item_id, rating, timestamp
       FROM ratings
       WHERE timestamp > '2024-01-01'
   """
   
   data = pd.read_sql_query(query, conn)
   conn.close()
   
   # Use with CoreRec
   from corerec.engines.unionizedFilterEngine import MatrixFactorization
   
   model = MatrixFactorization()
   model.fit(data)

Evaluation and Metrics
-----------------------

Evaluate your model's performance:

.. code-block:: python

   from corerec.evaluation import Evaluator
   from sklearn.model_selection import train_test_split
   
   # Split data
   train_data, test_data = train_test_split(data, test_size=0.2)
   
   # Train model
   model.fit(train_data)
   
   # Evaluate with multiple metrics
   evaluator = Evaluator(metrics=[
       'precision@5',
       'recall@5',
       'ndcg@5',
       'map@5',
       'hit_rate@5',
       'coverage',
       'diversity'
   ])
   
   results = evaluator.evaluate(model, test_data)
   
   # Print results
   for metric, value in results.items():
       print(f"{metric}: {value:.4f}")

Model Persistence
-----------------

Save and load models:

.. code-block:: python

   # Train and save
   model = MatrixFactorization(n_factors=50)
   model.fit(train_data)
   model.save('my_recommender.pkl')
   
   # Later, load and use
   from corerec.engines.unionizedFilterEngine import MatrixFactorization
   
   loaded_model = MatrixFactorization.load('my_recommender.pkl')
   recommendations = loaded_model.recommend(user_id=123, top_k=10)

Hyperparameter Tuning
----------------------

Optimize model parameters:

.. code-block:: python

   from corerec.hyper_train import HyperparameterTuner
   
   # Define parameter grid
   param_grid = {
       'n_factors': [10, 20, 50, 100],
       'learning_rate': [0.001, 0.01, 0.1],
       'regularization': [0.001, 0.01, 0.1]
   }
   
   # Initialize tuner
   tuner = HyperparameterTuner(
       model_class=MatrixFactorization,
       param_grid=param_grid,
       cv=5,
       metric='ndcg@10'
   )
   
   # Find best parameters
   best_params = tuner.fit(train_data, test_data)
   
   print(f"Best parameters: {best_params}")
   
   # Train final model with best parameters
   final_model = MatrixFactorization(**best_params)
   final_model.fit(train_data)

Next Steps
----------

Now that you've completed the quickstart:

1. **Explore More Examples**: Check out :doc:`examples/overview` for detailed examples
2. **Learn About Engines**: Understand different :doc:`engines/overview` 
3. **Deep Dive into API**: Read :doc:`api/overview` for detailed documentation
4. **Production Deployment**: Learn about :doc:`advanced/serving` and :doc:`advanced/pipelines`
5. **Custom Models**: Build your own models using the :doc:`api/base_recommender`

Tips for Success
----------------

* **Start with simple models** and gradually increase complexity
* **Validate with appropriate metrics** for your use case
* **Consider cold-start problems** for new users/items
* **Monitor performance** in production
* **Iterate based on user feedback**
* **Keep data quality high** - garbage in, garbage out!

Common Patterns
---------------

**Pattern 1: Hybrid Recommendations**

.. code-block:: python

   from corerec.hybrid import HybridRecommender
   
   # Combine content-based and collaborative filtering
   content_model = TFIDFRecommender()
   collab_model = MatrixFactorization()
   
   hybrid = HybridRecommender(
       models=[content_model, collab_model],
       weights=[0.3, 0.7]  # Weight for each model
   )
   
   hybrid.fit(data)
   recommendations = hybrid.recommend(user_id=1, top_k=10)

**Pattern 2: Re-ranking**

.. code-block:: python

   # Get initial recommendations
   candidates = model.recommend(user_id=1, top_k=100)
   
   # Re-rank based on business rules
   from corerec.pipelines import ReRanker
   
   reranker = ReRanker(
       diversity_weight=0.3,
       freshness_weight=0.2,
       popularity_penalty=0.1
   )
   
   final_recs = reranker.rerank(candidates, top_k=10)

**Pattern 3: A/B Testing**

.. code-block:: python

   from corerec.serving import ABTestServer
   
   # Deploy multiple models for A/B testing
   ab_server = ABTestServer(
       models={'model_a': model_a, 'model_b': model_b},
       traffic_split={'model_a': 0.5, 'model_b': 0.5}
   )
   
   # Get recommendations (randomly assigned to a model)
   recommendations = ab_server.recommend(user_id=1, top_k=10)

Need Help?
----------

* Check :doc:`examples/overview` for more examples
* Visit the `GitHub repository <https://github.com/vishesh9131/corerec>`_
* Join our community at https://corerec.tech
* Email: vishesh@corerec.tech

