Installation Guide
==================

This guide covers different ways to install CoreRec and its dependencies.

Quick Installation
------------------

The simplest way to install CoreRec is using pip:

.. code-block:: bash

   pip install corerec

To upgrade to the latest version:

.. code-block:: bash

   pip install --upgrade corerec

Requirements
------------

CoreRec requires:

* Python 3.7 or higher
* pip (Python package installer)

Core Dependencies
^^^^^^^^^^^^^^^^^

CoreRec automatically installs these core dependencies:

* **numpy** - Numerical computing
* **pandas** - Data manipulation
* **scipy** - Scientific computing
* **scikit-learn** - Machine learning utilities

Optional Dependencies
^^^^^^^^^^^^^^^^^^^^^

For full functionality, you may need:

**Deep Learning** (for neural network models):

.. code-block:: bash

   pip install torch torchvision
   # or
   pip install tensorflow

**Graph Algorithms**:

.. code-block:: bash

   pip install networkx

**Visualization**:

.. code-block:: bash

   pip install matplotlib seaborn plotly

**Advanced Models**:

.. code-block:: bash

   pip install lightgbm xgboost

Installation Methods
--------------------

Method 1: Install from PyPI (Recommended)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: bash

   # Basic installation
   pip install corerec
   
   # With all extras
   pip install corerec[all]
   
   # With specific extras
   pip install corerec[torch]  # For PyTorch models
   pip install corerec[viz]    # For visualization
   pip install corerec[dev]    # For development

Method 2: Install from Source
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Clone the repository and install:

.. code-block:: bash

   # Clone the repository
   git clone https://github.com/vishesh9131/corerec.git
   cd corerec
   
   # Install in development mode
   pip install -e .
   
   # Or install normally
   pip install .

Method 3: Install from GitHub
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Install directly from the GitHub repository:

.. code-block:: bash

   pip install git+https://github.com/vishesh9131/corerec.git

For a specific branch:

.. code-block:: bash

   pip install git+https://github.com/vishesh9131/corerec.git@branch-name

Virtual Environment Setup
--------------------------

It's recommended to use a virtual environment:

Using venv
^^^^^^^^^^

.. code-block:: bash

   # Create virtual environment
   python -m venv corerec_env
   
   # Activate (Linux/Mac)
   source corerec_env/bin/activate
   
   # Activate (Windows)
   corerec_env\Scripts\activate
   
   # Install CoreRec
   pip install corerec
   
   # Deactivate when done
   deactivate

Using conda
^^^^^^^^^^^

.. code-block:: bash

   # Create conda environment
   conda create -n corerec_env python=3.9
   
   # Activate
   conda activate corerec_env
   
   # Install CoreRec
   pip install corerec
   
   # Deactivate when done
   conda deactivate

Platform-Specific Instructions
-------------------------------

Linux
^^^^^

.. code-block:: bash

   # Update package manager
   sudo apt-get update
   
   # Install Python and pip (if not already installed)
   sudo apt-get install python3 python3-pip
   
   # Install CoreRec
   pip3 install corerec

macOS
^^^^^

.. code-block:: bash

   # Install Homebrew (if not installed)
   /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
   
   # Install Python
   brew install python
   
   # Install CoreRec
   pip3 install corerec

Windows
^^^^^^^

1. Download and install Python from `python.org <https://www.python.org/downloads/>`_
2. Ensure "Add Python to PATH" is checked during installation
3. Open Command Prompt or PowerShell:

.. code-block:: bash

   # Upgrade pip
   python -m pip install --upgrade pip
   
   # Install CoreRec
   pip install corerec

Docker Installation
-------------------

Use CoreRec with Docker:

Create a Dockerfile:

.. code-block:: dockerfile

   FROM python:3.9-slim
   
   WORKDIR /app
   
   # Install CoreRec
   RUN pip install --no-cache-dir corerec torch
   
   # Copy your application
   COPY . /app
   
   CMD ["python", "your_script.py"]

Build and run:

.. code-block:: bash

   # Build image
   docker build -t corerec-app .
   
   # Run container
   docker run -it corerec-app

Verifying Installation
----------------------

After installation, verify that CoreRec is working:

.. code-block:: python

   import corerec
   
   # Check version
   print(corerec.__version__)
   
   # Try importing main components
   from corerec.engines.contentFilterEngine import TFIDFRecommender
   from corerec.engines.unionizedFilterEngine import MatrixFactorization
   
   print("CoreRec installed successfully!")

You can also run the test suite:

.. code-block:: bash

   # Install pytest if not already installed
   pip install pytest
   
   # Run tests (if you have the source code)
   pytest tests/

Development Installation
------------------------

For contributing to CoreRec:

.. code-block:: bash

   # Clone the repository
   git clone https://github.com/vishesh9131/corerec.git
   cd corerec
   
   # Create virtual environment
   python -m venv venv
   source venv/bin/activate  # or venv\Scripts\activate on Windows
   
   # Install in editable mode with development dependencies
   pip install -e ".[dev]"
   
   # Install pre-commit hooks
   pre-commit install
   
   # Run tests
   pytest tests/

GPU Support
-----------

For GPU-accelerated models (requires CUDA):

PyTorch with CUDA
^^^^^^^^^^^^^^^^^

.. code-block:: bash

   # Check CUDA version
   nvidia-smi
   
   # Install PyTorch with CUDA support
   # For CUDA 11.8
   pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118
   
   # Install CoreRec
   pip install corerec

TensorFlow with CUDA
^^^^^^^^^^^^^^^^^^^^

.. code-block:: bash

   # Install TensorFlow with GPU support
   pip install tensorflow[and-cuda]
   
   # Install CoreRec
   pip install corerec

Verify GPU availability:

.. code-block:: python

   import torch
   print(f"CUDA available: {torch.cuda.is_available()}")
   print(f"CUDA version: {torch.version.cuda}")
   print(f"GPU count: {torch.cuda.device_count()}")

Troubleshooting
---------------

Common Issues
^^^^^^^^^^^^^

**ImportError: No module named 'corerec'**

Solution:

.. code-block:: bash

   pip install --force-reinstall corerec

**Permission Denied**

Solution:

.. code-block:: bash

   pip install --user corerec

**SSL Certificate Errors**

Solution:

.. code-block:: bash

   pip install --trusted-host pypi.org --trusted-host files.pythonhosted.org corerec

**Dependency Conflicts**

Solution:

.. code-block:: bash

   # Create fresh virtual environment
   python -m venv fresh_env
   source fresh_env/bin/activate
   pip install corerec

Getting Help
------------

If you encounter installation issues:

1. Check the `GitHub Issues <https://github.com/vishesh9131/corerec/issues>`_
2. Search for similar problems
3. Create a new issue with:
   
   * Python version (``python --version``)
   * Operating system
   * Full error message
   * Installation command used

Next Steps
----------

After successful installation:

* Follow the :doc:`quickstart` tutorial
* Explore :doc:`examples/overview`
* Read the :doc:`getting_started` guide

