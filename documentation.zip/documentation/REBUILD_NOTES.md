# Documentation Rebuild Guide

## Quick Rebuild Commands

### Method 1: Use the Script
```bash
cd /Users/visheshyadav/Documents/GitHub/CoreRec/documentation
./rebuild_docs.sh
```

### Method 2: Manual Commands
```bash
cd /Users/visheshyadav/Documents/GitHub/CoreRec/documentation
make clean && make html
open _build/html/index.html
```

## Current Theme

**Theme**: Furo (2025.9.25)
- Modern, clean design
- Mobile responsive
- Dark mode support
- Great navigation

## Required Packages

Make sure these are installed:
```bash
pip install sphinx
pip install sphinx-design
pip install furo
pip install sphinxcontrib-applehelp
pip install sphinxcontrib-devhelp
pip install sphinxcontrib-htmlhelp
pip install sphinxcontrib-jsmath
pip install sphinxcontrib-qthelp
pip install sphinxcontrib-serializinghtml
```

Or install all at once:
```bash
pip install sphinx sphinx-design furo
```

## Switching Themes

To switch themes, edit `conf.py` and change:
```python
html_theme = 'furo'  # Change this
```

### Popular Themes

```python
# Furo (current)
html_theme = 'furo'

# Read the Docs
html_theme = 'sphinx_rtd_theme'  # pip install sphinx-rtd-theme

# Book theme
html_theme = 'sphinx_book_theme'  # pip install sphinx-book-theme

# PyData
html_theme = 'pydata_sphinx_theme'  # pip install pydata-sphinx-theme

# Awesome theme (original)
html_theme = 'sphinxawesome_theme'  # pip install sphinxawesome-theme
```

After changing theme:
1. Install the theme package if needed
2. Run: `make clean && make html`

## Troubleshooting

### Error: "No module named 'sphinx_design'"
```bash
pip install sphinx-design
```

### Error: "no theme named 'X' found"
```bash
pip install [theme-package-name]
```

### Error: Import errors
Check that all extensions in `conf.py` are installed:
```python
extensions = [
    'sphinx.ext.autodoc',
    'sphinx.ext.napoleon',
    'sphinx.ext.viewcode',
    'sphinx.ext.todo',
    'sphinx.ext.coverage',
    'sphinx.ext.intersphinx',
    'sphinx.ext.autosummary',
    'sphinx.ext.githubpages',
    'sphinx_design',  # Must be installed!
]
```

## Build Output

- **Location**: `_build/html/`
- **Main file**: `_build/html/index.html`
- **Size**: ~3-4 MB
- **Pages**: 61 HTML pages

## Auto-Rebuild (Development)

For auto-rebuilding on file changes:
```bash
pip install sphinx-autobuild
sphinx-autobuild . _build/html
# Opens at http://127.0.0.1:8000
```

## Last Build

- **Date**: October 12, 2025
- **Theme**: Furo 2025.9.25
- **Status**: ✅ Success
- **Warnings**: 94 (mostly optional dependencies)

---

Happy documenting! 📚

