Model Evaluation
================

Comprehensive model evaluation strategies.

Evaluation Metrics
------------------

.. code-block:: python

   from corerec.evaluation import Evaluator
   
   evaluator = Evaluator(metrics=[
       'precision@10',
       'recall@10',
       'ndcg@10',
       'map@10',
       'coverage',
       'diversity'
   ])
   
   results = evaluator.evaluate(model, test_data)

Cross-Validation
----------------

.. code-block:: python

   from corerec.evaluation import cross_validate
   
   scores = cross_validate(
       model,
       data,
       cv=5,
       metrics=['rmse', 'mae']
   )

See Also
--------

* :doc:`../reference/metrics` - Metrics reference
* :doc:`training` - Model training

