Real-World Examples
===================

Production-ready examples for real-world recommendation systems.

Instagram Reels Recommendations
--------------------------------

Complete example of building an Instagram Reels-like recommendation system.

Overview
^^^^^^^^

This example demonstrates:

* Content-based filtering using video features
* Collaborative filtering using engagement data
* Hybrid recommendations
* Real-time serving
* A/B testing setup

Code Location
^^^^^^^^^^^^^

``examples/instagram_reels_with_real_data.py``

Key Features
^^^^^^^^^^^^

.. code-block:: python

   # Load and preprocess data
   from examples.instagram_reels_with_real_data import InstagramReelsRecommender
   
   recommender = InstagramReelsRecommender(
       content_weight=0.3,
       collab_weight=0.7
   )
   
   # Train on engagement data
   recommender.fit(engagement_data)
   
   # Get personalized feed
   feed = recommender.recommend(
       user_id=123,
       top_k=20,
       diversity_weight=0.2
   )

Full Implementation
^^^^^^^^^^^^^^^^^^^

The complete implementation includes:

1. Data preprocessing
2. Feature engineering
3. Model training
4. Evaluation
5. Serving infrastructure
6. Monitoring setup

See ``examples/INSTAGRAM_REELS_README.md`` for detailed documentation.

YouTube Video Recommendations
------------------------------

Building a YouTube-style recommendation system.

Features
^^^^^^^^

* Sequential viewing patterns
* Multi-objective optimization (watch time, CTR)
* Two-tower architecture
* Candidate generation and ranking

Code Snippet
^^^^^^^^^^^^

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.nn_base import WideDeep_base
   from corerec.engines.unionizedFilterEngine.attention_mechanism_base import SASRec_base
   
   # Candidate generation with SASRec
   candidate_gen = SASRec_base(item_num=1000000, max_len=50)
   candidate_gen.fit(watch_sequences, epochs=20)
   
   # Ranking with Wide & Deep
   ranker = WideDeep_base(
       wide_feature_dims=wide_dims,
       deep_feature_dims=deep_dims
   )
   ranker.fit(engagement_data, epochs=10)
   
   # Two-stage recommendation
   candidates = candidate_gen.recommend(user_id=123, top_k=500)
   final_recs = ranker.rerank(candidates, top_k=20)

E-Commerce Product Recommendations
-----------------------------------

Building product recommendations for e-commerce.

Session-Based Recommendations
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.attention_mechanism_base import GRU4Rec
   
   # Session data
   sessions = pd.DataFrame({
       'session_id': [...],
       'product_id': [...],
       'timestamp': [...],
       'action': [...]  # view, add_to_cart, purchase
   })
   
   # Train session-based model
   model = GRU4Rec(num_items=100000, hidden_size=100)
   model.fit(sessions, epochs=15)
   
   # Real-time recommendations during session
   next_products = model.predict_next(session_id='abc123', top_k=10)

Personalized Ranking
^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.nn_base import DeepFM_base
   
   # Multi-feature data
   data = pd.DataFrame({
       'user_id': [...],
       'product_id': [...],
       'user_segment': [...],
       'product_category': [...],
       'price_range': [...],
       'season': [...],
       'purchased': [...]
   })
   
   # Train ranker
   ranker = DeepFM_base(feature_dims=feature_dims)
   ranker.fit(data, target_column='purchased', epochs=10)

Music Streaming Recommendations
--------------------------------

Spotify-style music recommendations.

Playlist Continuation
^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.attention_mechanism_base import SASRec_base
   
   # Listening history
   listening = pd.DataFrame({
       'user_id': [...],
       'track_id': [...],
       'playlist_id': [...],
       'timestamp': [...]
   })
   
   # Train sequential model
   model = SASRec_base(item_num=1000000, max_len=100)
   model.fit(listening, epochs=25)
   
   # Continue playlist
   next_tracks = model.recommend(user_id=123, top_k=30)

Discover Weekly
^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.hybrid import HybridRecommender
   from corerec.engines.contentFilterEngine.nn_based_algorithms import Word2Vec
   from corerec.engines.unionizedFilterEngine import MatrixFactorization
   
   # Content-based using audio features
   content_model = Word2Vec(vector_size=128)
   content_model.fit(audio_features)
   
   # Collaborative filtering
   collab_model = MatrixFactorization(n_factors=50)
   collab_model.fit(listening_history)
   
   # Hybrid recommendations
   hybrid = HybridRecommender(
       models=[content_model, collab_model],
       weights=[0.4, 0.6]
   )
   
   discover_weekly = hybrid.recommend(user_id=123, top_k=30)

News Article Recommendations
-----------------------------

Personalized news feed.

Content-Based Filtering
^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.engines.contentFilterEngine import TFIDFRecommender
   
   # Article content
   articles = pd.DataFrame({
       'article_id': [...],
       'title': [...],
       'content': [...],
       'category': [...],
       'publish_time': [...]
   })
   
   # TF-IDF similarity
   recommender = TFIDFRecommender()
   recommender.fit(articles, text_column='content')
   
   # User reading history
   def get_recommendations(user_id, reading_history, top_k=10):
       # Get similar articles to recently read
       candidates = []
       for article_id in reading_history[-5:]:  # Last 5 articles
           similar = recommender.recommend(item_id=article_id, top_k=20)
           candidates.extend(similar)
       
       # Deduplicate and rank
       candidates = list(set(candidates))
       return candidates[:top_k]

Contextual Recommendations
^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.engines.contentFilterEngine.context_personalization import context_aware
   
   model = context_aware.ContextAwareRecommender()
   
   # Include context (time, device, location)
   recommendations = model.recommend(
       user_id=123,
       context={
           'time_of_day': 'morning',
           'device': 'mobile',
           'location': 'commute'
       },
       top_k=10
   )

Job Recommendations
-------------------

Matching candidates to jobs.

Two-Sided Recommendations
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.graph_based_base import GNN_base
   
   # Bipartite graph: candidates <-> jobs
   interactions = pd.DataFrame({
       'candidate_id': [...],
       'job_id': [...],
       'applied': [...],
       'interviewed': [...],
       'hired': [...]
   })
   
   # Build bipartite graph
   model = GNN_base(embedding_dim=128)
   model.build_bipartite_graph(interactions)
   model.fit(interactions, epochs=50)
   
   # Recommend jobs to candidate
   job_recs = model.recommend(user_id=candidate_123, top_k=20)
   
   # Recommend candidates to job
   candidate_recs = model.recommend_reverse(item_id=job_456, top_k=50)

Dating App Recommendations
---------------------------

User matching for dating apps.

Preference-Based Matching
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.nn_base import DeepFM_base
   
   # User preferences and features
   data = pd.DataFrame({
       'user_a': [...],
       'user_b': [...],
       'age_a': [...],
       'age_b': [...],
       'location_distance': [...],
       'shared_interests': [...],
       'matched': [...]  # 0 or 1
   })
   
   # Train matching model
   model = DeepFM_base(feature_dims=feature_dims)
   model.fit(data, target_column='matched', epochs=10)
   
   # Get potential matches
   def get_matches(user_id, top_k=20):
       candidates = get_eligible_users(user_id)
       scores = [model.predict(user_a=user_id, user_b=c) for c in candidates]
       matches = sorted(zip(candidates, scores), key=lambda x: x[1], reverse=True)
       return matches[:top_k]

Production Deployment
---------------------

Model Serving
^^^^^^^^^^^^^

.. code-block:: python

   from corerec.serving import ModelServer
   
   # Initialize server
   server = ModelServer(
       model=trained_model,
       host='0.0.0.0',
       port=8000,
       cache_size=10000
   )
   
   # Start serving
   server.start()
   
   # API endpoint automatically created:
   # POST /recommend
   # {
   #   "user_id": 123,
   #   "top_k": 10,
   #   "context": {...}
   # }

A/B Testing
^^^^^^^^^^^

.. code-block:: python

   from corerec.serving import ABTestServer
   
   # Deploy multiple models for A/B testing
   ab_server = ABTestServer(
       models={
           'baseline': baseline_model,
           'variant_a': new_model_a,
           'variant_b': new_model_b
       },
       traffic_split={
           'baseline': 0.5,
           'variant_a': 0.25,
           'variant_b': 0.25
       }
   )
   
   ab_server.start()

Monitoring
^^^^^^^^^^

.. code-block:: python

   from corerec.serving import ModelMonitor
   
   monitor = ModelMonitor(
       metrics=['latency', 'throughput', 'error_rate', 'ctr'],
       alert_thresholds={
           'latency_p99': 100,  # ms
           'error_rate': 0.01   # 1%
       }
   )
   
   # Log predictions
   monitor.log_prediction(
       user_id=123,
       recommendations=recs,
       latency_ms=45,
       model_version='v1.2.3'
   )

Running Examples
----------------

.. code-block:: bash

   # Instagram Reels example
   python examples/instagram_reels_with_real_data.py
   
   # Demo frontends
   python examples/demo_frontends_example.py
   
   # Full test suite
   python examples/run_all_algo_tests_example.py

Documentation
-------------

Each real-world example includes:

* README with detailed explanation
* Requirements and setup instructions
* Data preprocessing steps
* Model training code
* Evaluation metrics
* Deployment guidelines

See ``examples/README.md`` and individual example READMEs for details.

See Also
--------

* :doc:`overview` - All examples
* :doc:`../advanced/serving` - Model serving
* :doc:`../advanced/pipelines` - Production pipelines

