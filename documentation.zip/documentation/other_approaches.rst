other\_approaches package
=========================

Submodules
----------

other\_approaches.ontology\_based module
----------------------------------------

.. automodule:: other_approaches.ontology_based
   :members:
   :undoc-members:
   :show-inheritance:

other\_approaches.rule\_based module
------------------------------------

.. automodule:: other_approaches.rule_based
   :members:
   :undoc-members:
   :show-inheritance:

other\_approaches.sentiment\_analysis module
--------------------------------------------

.. automodule:: other_approaches.sentiment_analysis
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: other_approaches
   :members:
   :undoc-members:
   :show-inheritance:
