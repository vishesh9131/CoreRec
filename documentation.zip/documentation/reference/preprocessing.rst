Preprocessing Reference
=======================

Data preprocessing utilities.

Data Preprocessor
-----------------

.. automodule:: corerec.preprocessing
   :members:
   :undoc-members:

Common Preprocessing Steps
---------------------------

Data Cleaning
^^^^^^^^^^^^^

.. code-block:: python

   from corerec.preprocessing import DataPreprocessor
   
   preprocessor = DataPreprocessor()
   clean_data = preprocessor.fit_transform(raw_data)

Feature Engineering
^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.preprocessing import FeatureEngineer
   
   engineer = FeatureEngineer()
   features = engineer.extract_features(data)

See Also
--------

* :doc:`utilities` - Other utilities
* :doc:`../getting_started` - Getting started guide

