Engines Overview
================

CoreRec provides multiple recommendation engines, each specialized for different types of recommendation tasks.

Engine Architecture
-------------------

CoreRec organizes recommendation algorithms into two main engines:

1. **ContentFilterEngine** - Content-based filtering
2. **UnionizedFilterEngine** - Collaborative and hybrid filtering

.. image:: ../_static/engines_architecture.png
   :alt: Engines Architecture
   :width: 600px

ContentFilterEngine
-------------------

Content-based filtering using item features and attributes.

**Key Features:**

* TF-IDF based similarity
* Neural network content models
* Context-aware recommendations
* Multi-modal content processing

**Best For:**

* Cold-start items (new items with no interactions)
* Feature-rich domains (movies, articles, products)
* Explainable recommendations

**Example:**

.. code-block:: python

   from corerec.engines.contentFilterEngine import TFIDFRecommender
   
   recommender = TFIDFRecommender()
   recommender.fit(item_features)
   similar_items = recommender.recommend(item_id=123, top_k=10)

UnionizedFilterEngine
---------------------

Collaborative filtering and hybrid approaches using user-item interactions.

**Algorithm Categories:**

1. **Matrix Factorization**
   
   * SVD, NMF, ALS
   * Probabilistic Matrix Factorization
   * Bayesian Personalized Ranking

2. **Neural Network Models**
   
   * DeepFM, DCN, Wide & Deep
   * DIN, DIEN (attention-based)
   * Neural Collaborative Filtering

3. **Graph-Based**
   
   * GNN, LightGCN
   * DeepWalk, Node2Vec
   * Graph Attention Networks

4. **Sequential/Attention**
   
   * SASRec (Self-Attention)
   * Transformer-based
   * RNN/LSTM models

**Best For:**

* Rich interaction data
* Personalized recommendations
* Capturing user behavior patterns
* Scalable production systems

**Example:**

.. code-block:: python

   from corerec.engines.unionizedFilterEngine import DeepFM_base
   
   model = DeepFM_base(feature_dims, embed_dim=32)
   model.fit(train_data, epochs=10)
   recommendations = model.recommend(user_id=123, top_k=10)

Engine Comparison
-----------------

.. list-table::
   :widths: 20 40 40
   :header-rows: 1

   * - Feature
     - ContentFilterEngine
     - UnionizedFilterEngine
   * - **Input Data**
     - Item features/attributes
     - User-item interactions
   * - **Cold Start**
     - Handles new items well
     - Requires interaction history
   * - **Personalization**
     - Limited (based on item similarity)
     - High (based on user preferences)
   * - **Explainability**
     - High (feature-based)
     - Lower (latent factors)
   * - **Scalability**
     - Moderate
     - High (with proper algorithms)
   * - **Data Requirements**
     - Item metadata
     - User-item interactions

Choosing an Engine
------------------

Decision Guide
^^^^^^^^^^^^^^

**Use ContentFilterEngine when:**

* You have rich item metadata
* Items are frequently added (cold-start)
* Explainability is important
* Limited user interaction data

**Use UnionizedFilterEngine when:**

* You have abundant interaction data
* Personalization is crucial
* User behavior patterns are important
* Scalability is a priority

**Use Hybrid Approach when:**

* You want best of both worlds
* Have both metadata and interactions
* Need to handle various scenarios

Hybrid Recommendations
----------------------

Combine multiple engines for better results:

.. code-block:: python

   from corerec.hybrid import HybridRecommender
   from corerec.engines.contentFilterEngine import TFIDFRecommender
   from corerec.engines.unionizedFilterEngine import MatrixFactorization
   
   # Initialize engines
   content_engine = TFIDFRecommender()
   collab_engine = MatrixFactorization()
   
   # Train separately
   content_engine.fit(item_features)
   collab_engine.fit(user_item_interactions)
   
   # Create hybrid
   hybrid = HybridRecommender(
       engines=[content_engine, collab_engine],
       weights=[0.3, 0.7],  # Weight for each engine
       strategy='weighted_average'  # or 'cascade', 'switch'
   )
   
   # Get recommendations
   recommendations = hybrid.recommend(user_id=123, top_k=10)

Engine Modules
--------------

.. toctree::
   :maxdepth: 2
   
   content_filter
   unionized_filter
   neural_networks
   graph_based
   matrix_factorization
   attention_mechanisms

Performance Considerations
--------------------------

Training Time
^^^^^^^^^^^^^

.. list-table::
   :widths: 30 30 40
   :header-rows: 1

   * - Engine Type
     - Training Speed
     - Notes
   * - TF-IDF
     - Fast
     - Linear with items
   * - Matrix Factorization
     - Medium
     - Depends on factors/iterations
   * - Neural Networks
     - Slow-Medium
     - GPU recommended
   * - Graph-Based
     - Medium-Slow
     - Depends on graph size

Inference Time
^^^^^^^^^^^^^^

.. list-table::
   :widths: 30 30 40
   :header-rows: 1

   * - Engine Type
     - Inference Speed
     - Notes
   * - TF-IDF
     - Fast
     - Pre-compute similarities
   * - Matrix Factorization
     - Very Fast
     - Simple dot products
   * - Neural Networks
     - Medium
     - Batch inference helps
   * - Graph-Based
     - Medium
     - Can pre-compute embeddings

Best Practices
--------------

1. **Start Simple**
   
   Begin with basic algorithms and increase complexity as needed.

2. **Benchmark Multiple Engines**
   
   Try different engines on your data to find the best fit.

3. **Consider Production Constraints**
   
   Factor in latency, throughput, and resource requirements.

4. **Use Hybrid Approaches**
   
   Combine engines to leverage multiple signals.

5. **Monitor Performance**
   
   Track metrics in production and iterate.

6. **Handle Cold Start**
   
   Plan for new users/items without history.

Next Steps
----------

* Explore :doc:`content_filter` for content-based filtering
* Learn about :doc:`unionized_filter` for collaborative filtering
* See :doc:`neural_networks` for deep learning models
* Check :doc:`graph_based` for graph algorithms
* Read :doc:`../examples/overview` for practical examples

See Also
--------

* :doc:`../api/overview` - API documentation
* :doc:`../algorithms/overview` - Algorithm details
* :doc:`../advanced/training` - Advanced training techniques

