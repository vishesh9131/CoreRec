Examples Overview
=================

CoreRec provides extensive examples demonstrating various recommendation algorithms and use cases.

Example Categories
------------------

.. toctree::
   :maxdepth: 2
   
   content_filter_examples
   unionized_filter_examples
   neural_network_examples
   real_world_examples

Quick Start Examples
--------------------

Basic Content-Based Filtering
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.engines.contentFilterEngine import TFIDFRecommender
   import pandas as pd
   
   # Item data
   items = pd.DataFrame({
       'item_id': [1, 2, 3, 4, 5],
       'description': [
           'Laptop computer for work',
           'Gaming laptop with GPU',
           'Tablet for reading',
           'Desktop computer',
           'Smartphone device'
       ]
   })
   
   # Train and recommend
   recommender = TFIDFRecommender()
   recommender.fit(items, text_column='description')
   similar_items = recommender.recommend(item_id=1, top_k=3)

Basic Collaborative Filtering
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.engines.unionizedFilterEngine import MatrixFactorization
   import pandas as pd
   
   # User-item ratings
   ratings = pd.DataFrame({
       'user_id': [1, 1, 2, 2, 3, 3],
       'item_id': [101, 102, 101, 103, 102, 103],
       'rating': [5, 4, 3, 5, 4, 5]
   })
   
   # Train and recommend
   model = MatrixFactorization(n_factors=10)
   model.fit(ratings)
   recommendations = model.recommend(user_id=1, top_k=5)

Running Examples
----------------

All examples are available in the ``examples/`` directory of the CoreRec repository.

From Command Line
^^^^^^^^^^^^^^^^^

.. code-block:: bash

   # Content filter examples
   python examples/content_filter_tfidf_example.py
   python examples/content_filter_quickstart.py
   
   # Unionized filter examples
   python examples/unionized_fast_example.py
   python examples/unionized_sar_example.py
   python examples/unionized_rbm_example.py
   
   # Deep learning examples
   python examples/engines_deepfm_example.py
   python examples/engines_dcn_example.py
   python examples/engines_sasrec_example.py
   
   # Graph-based examples
   python examples/engines_gnnrec_example.py
   
   # Real-world examples
   python examples/instagram_reels_with_real_data.py
   python examples/demo_frontends_example.py

From Python
^^^^^^^^^^^

.. code-block:: python

   # Import and run example functions
   from examples import content_filter_quickstart
   
   content_filter_quickstart.main()

Example Datasets
----------------

Sample Data Included
^^^^^^^^^^^^^^^^^^^^

CoreRec includes sample datasets in ``sample_data/``:

* ``youtube_demo.csv`` - Video recommendations
* ``spotify_demo.csv`` - Music recommendations
* ``netflix_demo.csv`` - Movie recommendations

Using Sample Data
^^^^^^^^^^^^^^^^^

.. code-block:: python

   import pandas as pd
   
   # Load sample data
   data = pd.read_csv('sample_data/youtube_demo.csv')
   
   print(f"Loaded {len(data)} interactions")
   print(f"Users: {data['user_id'].nunique()}")
   print(f"Items: {data['video_id'].nunique()}")

Creating Your Own Dataset
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from examples.utils_example_data import generate_synthetic_data
   
   # Generate synthetic dataset
   data = generate_synthetic_data(
       n_users=1000,
       n_items=5000,
       n_interactions=10000,
       rating_scale=(1, 5)
   )
   
   # Save for later use
   data.to_csv('my_dataset.csv', index=False)

Example Patterns
----------------

Pattern 1: Train-Test Split
^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from sklearn.model_selection import train_test_split
   
   # Split data
   train_data, test_data = train_test_split(
       data,
       test_size=0.2,
       random_state=42
   )
   
   # Train
   model.fit(train_data)
   
   # Evaluate
   from corerec.evaluation import Evaluator
   evaluator = Evaluator(metrics=['precision@10', 'recall@10'])
   results = evaluator.evaluate(model, test_data)

Pattern 2: Cross-Validation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from sklearn.model_selection import KFold
   
   kf = KFold(n_splits=5, shuffle=True, random_state=42)
   
   scores = []
   for train_idx, test_idx in kf.split(data):
       train_data = data.iloc[train_idx]
       test_data = data.iloc[test_idx]
       
       model.fit(train_data)
       score = evaluator.evaluate(model, test_data)
       scores.append(score)
   
   print(f"Average score: {np.mean(scores):.4f}")

Pattern 3: Hyperparameter Tuning
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.hyper_train import HyperparameterTuner
   
   param_grid = {
       'n_factors': [10, 20, 50],
       'learning_rate': [0.001, 0.01, 0.1]
   }
   
   tuner = HyperparameterTuner(
       model_class=MatrixFactorization,
       param_grid=param_grid,
       cv=5
   )
   
   best_params = tuner.fit(data)

Pattern 4: Model Comparison
^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.engines.unionizedFilterEngine import (
       MatrixFactorization,
       ALSRecommender,
       FastRecommender
   )
   
   models = {
       'MF': MatrixFactorization(n_factors=50),
       'ALS': ALSRecommender(factors=50),
       'Fast': FastRecommender(embedding_dim=50)
   }
   
   results = {}
   for name, model in models.items():
       model.fit(train_data)
       score = evaluator.evaluate(model, test_data)
       results[name] = score
   
   # Print comparison
   for name, score in results.items():
       print(f"{name}: {score:.4f}")

Interactive Examples
--------------------

Jupyter Notebooks
^^^^^^^^^^^^^^^^^

Interactive notebooks are available in ``examples/notebooks/``:

* ``01_content_filtering.ipynb`` - Content-based filtering tutorial
* ``02_collaborative_filtering.ipynb`` - Collaborative filtering tutorial
* ``03_deep_learning.ipynb`` - Deep learning models
* ``04_graph_based.ipynb`` - Graph algorithms
* ``05_real_world_case_studies.ipynb`` - Real-world examples

Streamlit Demos
^^^^^^^^^^^^^^^

Run interactive web demos:

.. code-block:: bash

   # Movie recommender demo
   streamlit run examples/demos/movie_recommender_demo.py
   
   # Product recommender demo
   streamlit run examples/demos/product_recommender_demo.py
   
   # Instagram Reels demo
   streamlit run examples/demos/instagram_reels_demo.py

Common Use Cases
----------------

E-Commerce Product Recommendations
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

See :doc:`real_world_examples` for complete implementation.

.. code-block:: python

   # Quick snippet
   from corerec.engines.unionizedFilterEngine.nn_base import DeepFM_base
   
   model = DeepFM_base(feature_dims={'user': 10000, 'product': 50000})
   model.fit(purchase_data, epochs=10)
   recommendations = model.recommend(user_id=123, top_k=10)

Video Streaming Recommendations
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.attention_mechanism_base import SASRec_base
   
   model = SASRec_base(item_num=100000, max_len=50)
   model.fit(watch_history, epochs=20)
   next_videos = model.recommend(user_id=456, top_k=10)

News Article Recommendations
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.engines.contentFilterEngine import TFIDFRecommender
   
   recommender = TFIDFRecommender()
   recommender.fit(articles, text_column='content')
   similar_articles = recommender.recommend(article_id=789, top_k=5)

Best Practices
--------------

1. **Start Simple**
   
   * Begin with basic examples
   * Understand the fundamentals
   * Gradually increase complexity

2. **Use Appropriate Data**
   
   * Match algorithm to data type
   * Ensure sufficient data quality
   * Handle missing values

3. **Evaluate Properly**
   
   * Use relevant metrics
   * Test on held-out data
   * Consider multiple metrics

4. **Iterate and Improve**
   
   * Start with default parameters
   * Tune based on results
   * Compare multiple approaches

5. **Document Your Work**
   
   * Keep track of experiments
   * Record parameters and results
   * Share findings with team

Additional Resources
--------------------

* :doc:`../quickstart` - Quick start guide
* :doc:`../engines/overview` - Engine documentation
* :doc:`../api/overview` - API reference
* `GitHub Examples <https://github.com/vishesh9131/corerec/tree/main/examples>`_

Need Help?
----------

* Check example READMEs in the examples directory
* Visit the `GitHub repository <https://github.com/vishesh9131/corerec>`_
* Open an issue for questions
* Email: vishesh@corerec.tech

