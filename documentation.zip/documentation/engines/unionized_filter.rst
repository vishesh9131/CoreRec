Unionized Filter Engine
=======================

The UnionizedFilterEngine provides collaborative filtering and hybrid recommendation algorithms.

Overview
--------

Collaborative filtering recommends items based on user-item interaction patterns, without requiring item content.

.. automodule:: corerec.engines.unionizedFilterEngine
   :members:
   :undoc-members:
   :show-inheritance:

Algorithm Categories
--------------------

The UnionizedFilterEngine organizes algorithms into four main categories:

1. **Matrix Factorization** - SVD, NMF, ALS
2. **Neural Networks** - DeepFM, DCN, DIN, DIEN
3. **Graph-Based** - GNN, LightGCN, DeepWalk
4. **Attention Mechanisms** - SASRec, Transformer-based

Matrix Factorization Algorithms
--------------------------------

See :doc:`matrix_factorization` for detailed documentation.

**Quick Example:**

.. code-block:: python

   from corerec.engines.unionizedFilterEngine import MatrixFactorization
   
   model = MatrixFactorization(n_factors=50, learning_rate=0.01)
   model.fit(ratings_data)
   recommendations = model.recommend(user_id=123, top_k=10)

Neural Network Algorithms
--------------------------

See :doc:`neural_networks` for detailed documentation.

**Available Models:**

* DeepFM
* DCN (Deep & Cross Network)
* DIN (Deep Interest Network)
* DIEN (Deep Interest Evolution Network)
* Wide & Deep
* NFM (Neural Factorization Machines)
* AFM (Attentional Factorization Machines)

**Quick Example:**

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.nn_base import DeepFM_base
   
   model = DeepFM_base(
       feature_dims={'user_id': 1000, 'item_id': 5000},
       embed_dim=32,
       mlp_dims=[128, 64, 32]
   )
   model.fit(data, epochs=10)

Graph-Based Algorithms
-----------------------

See :doc:`graph_based` for detailed documentation.

**Available Models:**

* GNN (Graph Neural Networks)
* LightGCN
* DeepWalk
* Node2Vec
* GraphSAGE

**Quick Example:**

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.graph_based_base import GNN_base
   
   model = GNN_base(embedding_dim=64, num_layers=3)
   model.build_graph(interactions)
   model.fit(interactions, epochs=50)

Attention Mechanisms
--------------------

See :doc:`attention_mechanisms` for detailed documentation.

**Available Models:**

* SASRec (Self-Attentive Sequential Recommendation)
* Transformer-based
* BERT4Rec

**Quick Example:**

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.attention_mechanism_base import SASRec_base
   
   model = SASRec_base(
       item_num=1000,
       max_len=50,
       hidden_units=64
   )
   model.fit(sequences, epochs=20)

Factory Pattern
---------------

Use the factory to create models dynamically:

.. code-block:: python

   from corerec.engines.unionizedFilterEngine import cr_unionizedFactory
   
   # Create model by name
   model = cr_unionizedFactory.create_model(
       'DeepFM',
       feature_dims=feature_dims,
       embed_dim=32
   )
   
   # Train
   model.fit(data)
   
   # Recommend
   recommendations = model.recommend(user_id=123, top_k=10)

Use Cases
---------

Movie Ratings Prediction
^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.engines.unionizedFilterEngine import MatrixFactorization
   import pandas as pd
   
   # Load MovieLens-style data
   ratings = pd.DataFrame({
       'user_id': [...],
       'movie_id': [...],
       'rating': [...],
       'timestamp': [...]
   })
   
   # Train model
   model = MatrixFactorization(n_factors=100)
   model.fit(ratings)
   
   # Predict rating
   predicted_rating = model.predict(user_id=1, item_id=50)
   
   # Get recommendations
   recommendations = model.recommend(user_id=1, top_k=10)

E-commerce CTR Prediction
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.nn_base import DeepFM_base
   
   # Prepare data with features
   data = pd.DataFrame({
       'user_id': [...],
       'item_id': [...],
       'user_age': [...],
       'user_gender': [...],
       'item_category': [...],
       'item_price': [...],
       'click': [...]  # Binary target
   })
   
   # Define feature dimensions
   feature_dims = {
       'user_id': 10000,
       'item_id': 50000,
       'user_age': 100,
       'user_gender': 2,
       'item_category': 50,
       'item_price': 1000
   }
   
   # Train DeepFM
   model = DeepFM_base(feature_dims=feature_dims, embed_dim=16)
   model.fit(data, target_column='click', epochs=10)
   
   # Predict CTR
   ctr = model.predict(user_id=123, item_id=456)

Sequential Recommendations
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.attention_mechanism_base import SASRec_base
   
   # User interaction sequences
   sequences = pd.DataFrame({
       'user_id': [1, 1, 1, 1, 2, 2, 2],
       'item_id': [101, 102, 103, 104, 201, 202, 203],
       'timestamp': [1, 2, 3, 4, 1, 2, 3]
   })
   
   # Train SASRec
   model = SASRec_base(item_num=1000, max_len=50)
   model.fit(sequences, epochs=20)
   
   # Predict next item
   next_items = model.recommend(user_id=1, top_k=5)

Social Network Recommendations
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.graph_based_base import GNN_base
   
   # User-user or user-item graph
   edges = pd.DataFrame({
       'source': [...],
       'target': [...],
       'weight': [...]
   })
   
   # Build graph and train
   model = GNN_base(embedding_dim=128)
   model.build_graph(edges)
   model.fit(edges, epochs=100)
   
   # Get recommendations
   recommendations = model.recommend(user_id=123, top_k=10)

Advanced Features
-----------------

Implicit Feedback
^^^^^^^^^^^^^^^^^

Handle implicit feedback (clicks, views) vs explicit ratings:

.. code-block:: python

   from corerec.engines.unionizedFilterEngine import ALSRecommender
   
   # Implicit feedback data
   implicit_data = pd.DataFrame({
       'user_id': [...],
       'item_id': [...],
       'confidence': [...]  # Number of interactions
   })
   
   model = ALSRecommender(
       factors=50,
       regularization=0.01,
       alpha=40  # Confidence scaling
   )
   model.fit(implicit_data)

Negative Sampling
^^^^^^^^^^^^^^^^^

Improve training with negative samples:

.. code-block:: python

   from corerec.engines.unionizedFilterEngine import BPRRecommender
   
   model = BPRRecommender(
       n_factors=50,
       learning_rate=0.01,
       negative_sampling_ratio=5  # 5 negative samples per positive
   )
   model.fit(data)

Multi-Task Learning
^^^^^^^^^^^^^^^^^^^^

Train on multiple objectives:

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.nn_base import ESMM_base
   
   # Multi-task data (e.g., click and purchase)
   model = ESMM_base(
       feature_dims=feature_dims,
       tasks=['click', 'purchase']
   )
   model.fit(data)

Side Information
^^^^^^^^^^^^^^^^

Incorporate user/item features:

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.nn_base import DCN_base
   
   # Data with side information
   data = pd.DataFrame({
       'user_id': [...],
       'item_id': [...],
       'user_age': [...],
       'user_location': [...],
       'item_category': [...],
       'item_brand': [...],
       'rating': [...]
   })
   
   model = DCN_base(feature_dims=feature_dims)
   model.fit(data)

Performance Optimization
------------------------

Batch Processing
^^^^^^^^^^^^^^^^

.. code-block:: python

   # Batch recommendations for multiple users
   user_ids = [1, 2, 3, 4, 5]
   batch_recommendations = model.batch_recommend(
       user_ids=user_ids,
       top_k=10,
       n_jobs=4  # Parallel processing
   )

GPU Acceleration
^^^^^^^^^^^^^^^^

.. code-block:: python

   # Enable GPU
   model = DeepFM_base(
       feature_dims=feature_dims,
       device='cuda'  # or 'cpu'
   )
   model.fit(data)

Model Compression
^^^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.optimization import ModelCompressor
   
   # Compress model for faster inference
   compressor = ModelCompressor()
   compressed_model = compressor.compress(
       model,
       method='quantization',
       precision='int8'
   )

Best Practices
--------------

1. **Data Preprocessing**
   
   * Handle missing values
   * Encode categorical features
   * Normalize numerical features
   * Split data properly (time-based for sequential)

2. **Hyperparameter Tuning**
   
   * Start with default parameters
   * Use validation set for tuning
   * Try grid search or Bayesian optimization
   * Monitor overfitting

3. **Evaluation**
   
   * Use appropriate metrics (RMSE for ratings, AUC for CTR)
   * Test on held-out data
   * Consider offline and online metrics
   * Evaluate diversity and coverage

4. **Production Deployment**
   
   * Pre-compute embeddings
   * Use approximate nearest neighbor search
   * Implement caching
   * Monitor latency and throughput

5. **Cold Start Handling**
   
   * Use content-based features
   * Implement fallback strategies
   * Collect initial preferences
   * Use popularity-based recommendations

Common Patterns
---------------

Model Stacking
^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.engines.unionizedFilterEngine import ModelStacker
   
   # Train multiple models
   model1 = MatrixFactorization()
   model2 = DeepFM_base(feature_dims)
   
   model1.fit(data)
   model2.fit(data)
   
   # Stack models
   stacker = ModelStacker(models=[model1, model2])
   stacker.fit(data)
   
   recommendations = stacker.recommend(user_id=123, top_k=10)

Two-Stage Ranking
^^^^^^^^^^^^^^^^^

.. code-block:: python

   # Stage 1: Candidate generation (fast)
   candidates = fast_model.recommend(user_id=123, top_k=100)
   
   # Stage 2: Re-ranking (accurate)
   from corerec.pipelines import ReRanker
   
   reranker = ReRanker(model=precise_model)
   final_recs = reranker.rerank(candidates, top_k=10)

See Also
--------

* :doc:`matrix_factorization` - Matrix factorization details
* :doc:`neural_networks` - Neural network models
* :doc:`graph_based` - Graph algorithms
* :doc:`attention_mechanisms` - Attention-based models
* :doc:`../examples/unionized_filter_examples` - More examples

