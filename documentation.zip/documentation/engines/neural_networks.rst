Neural Network Models
=====================

Deep learning models for recommendation systems in CoreRec.

Overview
--------

CoreRec provides state-of-the-art neural network architectures for recommendations, including factorization machines, attention mechanisms, and deep learning hybrids.

Available Models
----------------

DeepFM
^^^^^^

Deep Factorization Machines combine FM and deep neural networks.

.. autoclass:: corerec.engines.unionizedFilterEngine.nn_base.DeepFM_base
   :members:
   :show-inheritance:

**Architecture:**

* Factorization Machine component for feature interactions
* Deep Neural Network for high-order interactions
* Shared embeddings between FM and DNN

**Example:**

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.nn_base import DeepFM_base
   
   model = DeepFM_base(
       feature_dims={'user_id': 1000, 'item_id': 5000, 'category': 50},
       embed_dim=16,
       mlp_dims=[128, 64, 32],
       dropout=0.2
   )
   
   model.fit(data, epochs=10, batch_size=256)
   predictions = model.predict(user_id=123, item_id=456)

DCN (Deep & Cross Network)
^^^^^^^^^^^^^^^^^^^^^^^^^^^

Explicitly models feature crosses at each layer.

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.nn_base import DCN_base
   
   model = DCN_base(
       feature_dims=feature_dims,
       embed_dim=16,
       n_cross_layers=3,
       mlp_dims=[128, 64],
       dropout=0.2
   )
   
   model.fit(data, epochs=10)

**Key Features:**

* Cross network for explicit feature crossing
* Deep network for implicit feature learning
* Efficient and effective for CTR prediction

DIN (Deep Interest Network)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Attention-based model that captures user interests.

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.nn_base import DIN_base
   
   model = DIN_base(
       feature_dims=feature_dims,
       embed_dim=16,
       attention_hidden_units=[80, 40]
   )
   
   model.fit(data, epochs=10)

**Key Features:**

* Local activation unit for attention
* Captures diverse user interests
* Effective for sequential/historical data

DIEN (Deep Interest Evolution Network)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Evolution of DIN with interest evolution layer.

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.nn_base import DIEN_base
   
   model = DIEN_base(
       feature_dims=feature_dims,
       embed_dim=16,
       gru_hidden_size=64,
       attention_size=40
   )
   
   model.fit(data, epochs=10)

**Key Features:**

* GRU-based interest evolution
* Attention mechanism
* Better captures temporal dynamics

Wide & Deep
^^^^^^^^^^^

Combines wide linear models and deep neural networks.

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.nn_base import WideDeep_base
   
   model = WideDeep_base(
       wide_feature_dims=wide_dims,
       deep_feature_dims=deep_dims,
       embed_dim=16,
       deep_layers=[128, 64, 32]
   )
   
   model.fit(data, epochs=10)

**Key Features:**

* Wide: memorization of frequent patterns
* Deep: generalization through embeddings
* Best of both linear and non-linear models

NFM (Neural Factorization Machines)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Neural network enhancement of FM.

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.nn_base import NFM_base
   
   model = NFM_base(
       feature_dims=feature_dims,
       embed_dim=16,
       mlp_dims=[128, 64],
       dropout=0.2
   )
   
   model.fit(data, epochs=10)

AFM (Attentional Factorization Machines)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

FM with attention mechanism on feature interactions.

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.nn_base import AFM_base
   
   model = AFM_base(
       feature_dims=feature_dims,
       embed_dim=16,
       attention_size=32,
       dropout=0.2
   )
   
   model.fit(data, epochs=10)

Model Comparison
----------------

.. list-table::
   :widths: 20 30 30 20
   :header-rows: 1

   * - Model
     - Best For
     - Complexity
     - Training Speed
   * - DeepFM
     - CTR prediction
     - Medium
     - Fast
   * - DCN
     - Feature crossing
     - Medium
     - Fast
   * - DIN
     - User interest modeling
     - Medium
     - Medium
   * - DIEN
     - Interest evolution
     - High
     - Slow
   * - Wide & Deep
     - Memorization + generalization
     - Medium
     - Fast
   * - NFM
     - Simple feature interactions
     - Low
     - Fast
   * - AFM
     - Weighted interactions
     - Low
     - Fast

Training Neural Models
----------------------

Basic Training
^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.nn_base import DeepFM_base
   import pandas as pd
   
   # Prepare data
   data = pd.read_csv('interactions.csv')
   
   # Initialize model
   model = DeepFM_base(feature_dims=feature_dims, embed_dim=16)
   
   # Train
   model.fit(
       data,
       epochs=10,
       batch_size=256,
       learning_rate=0.001,
       validation_split=0.2
   )

Advanced Training
^^^^^^^^^^^^^^^^^

.. code-block:: python

   # Train with custom settings
   model.fit(
       data,
       epochs=20,
       batch_size=512,
       learning_rate=0.001,
       optimizer='adam',
       loss='binary_crossentropy',
       metrics=['auc', 'logloss'],
       validation_split=0.2,
       early_stopping=True,
       patience=3,
       callbacks=[learning_rate_scheduler, tensorboard]
   )

Distributed Training
^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.async_ddp import DistributedTrainer
   
   # Initialize distributed training
   trainer = DistributedTrainer(
       model=model,
       world_size=4,  # 4 GPUs
       backend='nccl'
   )
   
   # Train across multiple GPUs
   trainer.fit(data, epochs=10)

Use Cases
---------

CTR Prediction
^^^^^^^^^^^^^^

Click-through rate prediction for ads/recommendations:

.. code-block:: python

   # Prepare ad click data
   ad_data = pd.DataFrame({
       'user_id': [...],
       'ad_id': [...],
       'user_age': [...],
       'user_gender': [...],
       'ad_category': [...],
       'clicked': [...]  # 0 or 1
   })
   
   # Train DeepFM for CTR
   model = DeepFM_base(feature_dims=feature_dims)
   model.fit(ad_data, target_column='clicked', epochs=10)
   
   # Predict CTR
   ctr = model.predict(user_id=123, ad_id=456)
   print(f"Predicted CTR: {ctr:.4f}")

Conversion Rate Prediction
^^^^^^^^^^^^^^^^^^^^^^^^^^^

Predict probability of purchase/conversion:

.. code-block:: python

   # E-commerce conversion data
   conversion_data = pd.DataFrame({
       'user_id': [...],
       'product_id': [...],
       'price': [...],
       'discount': [...],
       'category': [...],
       'converted': [...]  # 0 or 1
   })
   
   # Train model
   model = DCN_base(feature_dims=feature_dims)
   model.fit(conversion_data, target_column='converted', epochs=10)
   
   # Predict conversion probability
   prob = model.predict(user_id=123, product_id=789)

Sequential User Behavior
^^^^^^^^^^^^^^^^^^^^^^^^^

Model user behavior sequences:

.. code-block:: python

   # User behavior sequence
   behavior_data = pd.DataFrame({
       'user_id': [...],
       'item_sequence': [...],  # List of historical items
       'target_item': [...],
       'clicked': [...]
   })
   
   # Train DIN
   model = DIN_base(feature_dims=feature_dims)
   model.fit(behavior_data, target_column='clicked', epochs=10)

Hyperparameter Tuning
----------------------

Grid Search
^^^^^^^^^^^

.. code-block:: python

   from corerec.hyper_train import GridSearchCV
   
   param_grid = {
       'embed_dim': [8, 16, 32],
       'mlp_dims': [[64, 32], [128, 64, 32], [256, 128, 64]],
       'dropout': [0.1, 0.2, 0.3],
       'learning_rate': [0.0001, 0.001, 0.01]
   }
   
   grid_search = GridSearchCV(
       model_class=DeepFM_base,
       param_grid=param_grid,
       cv=5,
       metric='auc'
   )
   
   best_params = grid_search.fit(data)
   print(f"Best parameters: {best_params}")

Bayesian Optimization
^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.hyper_train import BayesianOptimization
   
   param_space = {
       'embed_dim': (8, 64),
       'learning_rate': (1e-4, 1e-2),
       'dropout': (0.0, 0.5)
   }
   
   optimizer = BayesianOptimization(
       model_class=DeepFM_base,
       param_space=param_space,
       n_trials=50
   )
   
   best_params = optimizer.optimize(data)

Best Practices
--------------

1. **Feature Engineering**
   
   * Use embeddings for categorical features
   * Normalize numerical features
   * Handle missing values properly
   * Create meaningful feature interactions

2. **Model Architecture**
   
   * Start with simple architectures
   * Gradually increase complexity
   * Use batch normalization
   * Apply dropout for regularization

3. **Training**
   
   * Use appropriate batch sizes
   * Monitor training and validation loss
   * Implement early stopping
   * Save checkpoints regularly

4. **Optimization**
   
   * Try different optimizers (Adam, AdamW, SGD)
   * Use learning rate scheduling
   * Consider gradient clipping
   * Balance positive/negative samples

5. **Evaluation**
   
   * Use appropriate metrics (AUC, LogLoss for CTR)
   * Test on held-out data
   * Monitor online metrics
   * A/B test in production

Common Issues
-------------

Overfitting
^^^^^^^^^^^

**Symptoms:** High training accuracy, low validation accuracy

**Solutions:**

* Increase dropout
* Add L2 regularization
* Use more training data
* Simplify model architecture
* Apply early stopping

Underfitting
^^^^^^^^^^^^

**Symptoms:** Low training and validation accuracy

**Solutions:**

* Increase model capacity (more layers/units)
* Train for more epochs
* Reduce regularization
* Better feature engineering
* Check data quality

Slow Training
^^^^^^^^^^^^^

**Solutions:**

* Increase batch size
* Use GPU acceleration
* Implement distributed training
* Optimize data loading
* Use mixed precision training

See Also
--------

* :doc:`../examples/neural_network_examples` - Detailed examples
* :doc:`../advanced/training` - Advanced training techniques
* :doc:`../reference/utilities` - Utility functions

