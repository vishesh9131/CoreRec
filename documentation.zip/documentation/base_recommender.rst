base\_recommender module
========================

.. automodule:: base_recommender
   :members:
   :undoc-members:
   :show-inheritance:
