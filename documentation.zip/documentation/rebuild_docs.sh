#!/bin/bash

echo "🧹 Cleaning previous build..."
make clean

echo ""
echo "🔨 Building HTML documentation..."
make html

echo ""
echo "✅ Build complete!"
echo ""
echo "📂 Documentation location:"
echo "   $(pwd)/_build/html/index.html"
echo ""
echo "🌐 To view, run:"
echo "   open _build/html/index.html"
echo ""
echo "Or serve locally:"
echo "   cd _build/html && python -m http.server 8000"
