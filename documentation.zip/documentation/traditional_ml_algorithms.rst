traditional\_ml\_algorithms package
===================================

Submodules
----------

traditional\_ml\_algorithms.LR module
-------------------------------------

.. automodule:: traditional_ml_algorithms.LR
   :members:
   :undoc-members:
   :show-inheritance:

traditional\_ml\_algorithms.decision\_tree module
-------------------------------------------------

.. automodule:: traditional_ml_algorithms.decision_tree
   :members:
   :undoc-members:
   :show-inheritance:

traditional\_ml\_algorithms.lightgbm module
-------------------------------------------

.. automodule:: traditional_ml_algorithms.lightgbm
   :members:
   :undoc-members:
   :show-inheritance:

traditional\_ml\_algorithms.svm module
--------------------------------------

.. automodule:: traditional_ml_algorithms.svm
   :members:
   :undoc-members:
   :show-inheritance:

traditional\_ml\_algorithms.tfidf module
----------------------------------------

.. automodule:: traditional_ml_algorithms.tfidf
   :members:
   :undoc-members:
   :show-inheritance:

traditional\_ml\_algorithms.vw module
-------------------------------------

.. automodule:: traditional_ml_algorithms.vw
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: traditional_ml_algorithms
   :members:
   :undoc-members:
   :show-inheritance:
