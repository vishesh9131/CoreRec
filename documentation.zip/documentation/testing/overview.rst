Testing Overview
================

CoreRec includes comprehensive test suites to ensure reliability and correctness.

Test Structure
--------------

The testing framework is organized into:

.. toctree::
   :maxdepth: 2
   
   unit_tests
   integration_tests
   smoke_tests

Test Organization
-----------------

Tests are located in the ``tests/`` directory:

.. code-block:: text

   tests/
   ├── __init__.py
   ├── engines_models_smoke_test.py
   ├── test_integration.py
   ├── contentFilterEngine/
   │   ├── test_tfidf.py
   │   ├── test_content_based.py
   │   └── ...
   └── unionizedFilterEngine/
       ├── test_matrix_factorization.py
       ├── test_als.py
       ├── nn_base/
       │   ├── test_deepfm.py
       │   ├── test_dcn.py
       │   └── ...
       └── graph_based_base/
           ├── test_gnn.py
           └── ...

Running Tests
-------------

All Tests
^^^^^^^^^

.. code-block:: bash

   # Run all tests
   pytest tests/
   
   # With coverage
   pytest tests/ --cov=corerec --cov-report=html
   
   # Verbose output
   pytest tests/ -v

Specific Test Suites
^^^^^^^^^^^^^^^^^^^^

.. code-block:: bash

   # Content filter tests
   pytest tests/contentFilterEngine/
   
   # Unionized filter tests
   pytest tests/unionizedFilterEngine/
   
   # Neural network tests
   pytest tests/unionizedFilterEngine/nn_base/
   
   # Graph-based tests
   pytest tests/unionizedFilterEngine/graph_based_base/
   
   # Smoke tests
   pytest tests/engines_models_smoke_test.py
   
   # Integration tests
   pytest tests/test_integration.py

Individual Tests
^^^^^^^^^^^^^^^^

.. code-block:: bash

   # Run specific test file
   pytest tests/test_FM_base.py
   
   # Run specific test function
   pytest tests/test_FM_base.py::test_fm_training
   
   # Run tests matching pattern
   pytest tests/ -k "deepfm"

Test Categories
---------------

Unit Tests
^^^^^^^^^^

Test individual components in isolation:

.. code-block:: python

   import pytest
   from corerec.engines.unionizedFilterEngine import MatrixFactorization
   
   def test_matrix_factorization_init():
       """Test MF initialization"""
       model = MatrixFactorization(n_factors=10)
       assert model.n_factors == 10
   
   def test_matrix_factorization_fit():
       """Test MF training"""
       import pandas as pd
       
       data = pd.DataFrame({
           'user_id': [1, 1, 2, 2],
           'item_id': [1, 2, 1, 3],
           'rating': [5, 4, 3, 5]
       })
       
       model = MatrixFactorization(n_factors=5)
       model.fit(data)
       
       assert model.user_factors is not None
       assert model.item_factors is not None

Integration Tests
^^^^^^^^^^^^^^^^^

Test component interactions:

.. code-block:: python

   def test_end_to_end_recommendation():
       """Test complete recommendation pipeline"""
       from corerec.preprocessing import DataPreprocessor
       from corerec.engines.unionizedFilterEngine import MatrixFactorization
       from corerec.evaluation import Evaluator
       
       # Preprocess
       preprocessor = DataPreprocessor()
       clean_data = preprocessor.fit_transform(raw_data)
       
       # Train
       model = MatrixFactorization()
       model.fit(train_data)
       
       # Evaluate
       evaluator = Evaluator()
       results = evaluator.evaluate(model, test_data)
       
       assert results['precision@10'] > 0

Smoke Tests
^^^^^^^^^^^

Quick sanity checks for all models:

.. code-block:: python

   def test_model_basic_functionality(model_class):
       """Test that model can be initialized, trained, and used"""
       model = model_class()
       model.fit(sample_data)
       recommendations = model.recommend(user_id=1, top_k=5)
       assert len(recommendations) == 5

Test Fixtures
-------------

Common test data and utilities:

.. code-block:: python

   import pytest
   import pandas as pd
   
   @pytest.fixture
   def sample_ratings():
       """Sample rating data"""
       return pd.DataFrame({
           'user_id': [1, 1, 2, 2, 3, 3],
           'item_id': [101, 102, 101, 103, 102, 103],
           'rating': [5, 4, 3, 5, 4, 5]
       })
   
   @pytest.fixture
   def sample_implicit():
       """Sample implicit feedback data"""
       return pd.DataFrame({
           'user_id': range(100),
           'item_id': [i % 50 for i in range(100)],
           'interaction': [1] * 100
       })

Parameterized Tests
-------------------

Test multiple configurations:

.. code-block:: python

   import pytest
   
   @pytest.mark.parametrize("n_factors,learning_rate", [
       (10, 0.01),
       (20, 0.01),
       (50, 0.001),
   ])
   def test_matrix_factorization_params(n_factors, learning_rate, sample_ratings):
       """Test MF with different parameters"""
       model = MatrixFactorization(
           n_factors=n_factors,
           learning_rate=learning_rate
       )
       model.fit(sample_ratings)
       assert model.user_factors.shape[1] == n_factors

Mock Objects
------------

Mock external dependencies:

.. code-block:: python

   from unittest.mock import Mock, patch
   
   def test_model_with_external_service():
       """Test model that depends on external service"""
       with patch('corerec.utils.external_api') as mock_api:
           mock_api.return_value = {'data': 'mocked'}
           
           model = MyModel()
           result = model.process()
           
           assert result is not None
           mock_api.assert_called_once()

Performance Tests
-----------------

Test speed and resource usage:

.. code-block:: python

   import time
   import pytest
   
   def test_recommendation_speed(sample_ratings):
       """Test recommendation latency"""
       model = MatrixFactorization()
       model.fit(sample_ratings)
       
       start = time.time()
       recommendations = model.recommend(user_id=1, top_k=10)
       latency = time.time() - start
       
       assert latency < 0.1  # Less than 100ms
   
   @pytest.mark.slow
   def test_large_scale():
       """Test with large dataset"""
       large_data = generate_large_dataset(n_users=10000, n_items=50000)
       model = MatrixFactorization()
       model.fit(large_data)

Coverage Reports
----------------

Generate coverage reports:

.. code-block:: bash

   # HTML coverage report
   pytest tests/ --cov=corerec --cov-report=html
   open htmlcov/index.html
   
   # Terminal report
   pytest tests/ --cov=corerec --cov-report=term
   
   # XML report (for CI)
   pytest tests/ --cov=corerec --cov-report=xml

Continuous Integration
----------------------

GitHub Actions workflow:

.. code-block:: yaml

   name: Tests
   
   on: [push, pull_request]
   
   jobs:
     test:
       runs-on: ubuntu-latest
       
       steps:
       - uses: actions/checkout@v2
       
       - name: Set up Python
         uses: actions/setup-python@v2
         with:
           python-version: 3.9
       
       - name: Install dependencies
         run: |
           pip install -e .
           pip install pytest pytest-cov
       
       - name: Run tests
         run: pytest tests/ --cov=corerec
       
       - name: Upload coverage
         uses: codecov/codecov-action@v2

Test Data
---------

Creating test data:

.. code-block:: python

   def generate_test_data(n_users=100, n_items=50, n_interactions=500):
       """Generate synthetic test data"""
       import numpy as np
       import pandas as pd
       
       np.random.seed(42)
       
       data = pd.DataFrame({
           'user_id': np.random.randint(1, n_users + 1, n_interactions),
           'item_id': np.random.randint(1, n_items + 1, n_interactions),
           'rating': np.random.randint(1, 6, n_interactions),
           'timestamp': range(n_interactions)
       })
       
       return data.drop_duplicates(subset=['user_id', 'item_id'])

Best Practices
--------------

1. **Write Tests First**
   
   * Test-driven development (TDD)
   * Define expected behavior
   * Write test before implementation

2. **Test Coverage**
   
   * Aim for >80% coverage
   * Focus on critical paths
   * Don't chase 100% blindly

3. **Test Independence**
   
   * Tests should not depend on each other
   * Use fixtures for setup/teardown
   * Clean up resources

4. **Descriptive Names**
   
   * Use clear test names
   * Describe what is being tested
   * Include expected behavior

5. **Fast Tests**
   
   * Keep unit tests fast (<1s)
   * Mark slow tests
   * Use mocks for external services

6. **Meaningful Assertions**
   
   * Test meaningful properties
   * Use appropriate assertions
   * Provide helpful error messages

Writing New Tests
-----------------

Template for new test:

.. code-block:: python

   import pytest
   import pandas as pd
   from corerec.engines.unionizedFilterEngine import NewModel
   
   class TestNewModel:
       """Tests for NewModel"""
       
       @pytest.fixture
       def sample_data(self):
           """Fixture for test data"""
           return pd.DataFrame({
               'user_id': [1, 1, 2, 2],
               'item_id': [1, 2, 1, 3],
               'rating': [5, 4, 3, 5]
           })
       
       def test_initialization(self):
           """Test model initialization"""
           model = NewModel(param1=10)
           assert model.param1 == 10
       
       def test_fit(self, sample_data):
           """Test model training"""
           model = NewModel()
           model.fit(sample_data)
           assert model.is_fitted
       
       def test_recommend(self, sample_data):
           """Test recommendation generation"""
           model = NewModel()
           model.fit(sample_data)
           recs = model.recommend(user_id=1, top_k=5)
           
           assert len(recs) <= 5
           assert all(isinstance(r, tuple) for r in recs)
       
       def test_predict(self, sample_data):
           """Test prediction"""
           model = NewModel()
           model.fit(sample_data)
           score = model.predict(user_id=1, item_id=2)
           
           assert isinstance(score, float)
           assert 0 <= score <= 5

Running Test Suite
------------------

Quick test run:

.. code-block:: bash

   # Fast smoke test
   pytest tests/engines_models_smoke_test.py -v
   
   # Core functionality
   pytest tests/test_integration.py -v
   
   # Full suite (may take time)
   pytest tests/ -v

See Also
--------

* :doc:`unit_tests` - Unit test documentation
* :doc:`integration_tests` - Integration test documentation
* :doc:`smoke_tests` - Smoke test documentation
* `pytest documentation <https://docs.pytest.org/>`_

