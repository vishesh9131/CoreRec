Content Filter Engine
=====================

The ContentFilterEngine provides content-based filtering algorithms that recommend items based on their features and attributes.

Overview
--------

Content-based filtering recommends items similar to those a user has interacted with in the past, based on item features.

.. automodule:: corerec.engines.contentFilterEngine
   :members:
   :undoc-members:
   :show-inheritance:

Available Algorithms
--------------------

TF-IDF Recommender
^^^^^^^^^^^^^^^^^^

Text-based similarity using TF-IDF vectors.

.. autoclass:: corerec.engines.contentFilterEngine.TFIDFRecommender
   :members:
   :show-inheritance:

**Features:**

* Fast and efficient
* Works well with text data
* No training required
* Explainable results

**Example:**

.. code-block:: python

   from corerec.engines.contentFilterEngine import TFIDFRecommender
   import pandas as pd
   
   # Item descriptions
   items = pd.DataFrame({
       'item_id': [1, 2, 3, 4, 5],
       'title': ['Product A', 'Product B', 'Product C', 'Product D', 'Product E'],
       'description': [
           'High quality laptop for professionals',
           'Gaming laptop with powerful GPU',
           'Lightweight laptop for students',
           'Desktop computer for gaming',
           'Professional workstation computer'
       ]
   })
   
   # Initialize and fit
   recommender = TFIDFRecommender()
   recommender.fit(items, text_column='description')
   
   # Find similar items
   similar_items = recommender.recommend(item_id=1, top_k=3)
   
   for item_id, score in similar_items:
       print(f"Item {item_id}: {score:.3f}")

Neural Content Models
^^^^^^^^^^^^^^^^^^^^^

Deep learning models for content-based filtering:

**Word2Vec Recommender**

.. code-block:: python

   from corerec.engines.contentFilterEngine.nn_based_algorithms import Word2Vec
   
   model = Word2Vec(vector_size=100, window=5, min_count=1)
   model.fit(item_texts)
   similar = model.recommend(item_id=1, top_k=10)

**Autoencoder**

.. code-block:: python

   from corerec.engines.contentFilterEngine.nn_based_algorithms import autoencoder
   
   model = autoencoder.AutoencoderRecommender(encoding_dim=64)
   model.fit(item_features)
   recommendations = model.recommend(item_id=1, top_k=10)

**CNN for Images**

.. code-block:: python

   from corerec.engines.contentFilterEngine.nn_based_algorithms import cnn
   
   model = cnn.CNNRecommender()
   model.fit(image_features)
   similar = model.recommend(item_id=1, top_k=10)

Context-Aware Recommendations
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Incorporate contextual information:

.. code-block:: python

   from corerec.engines.contentFilterEngine.context_personalization import context_aware
   
   model = context_aware.ContextAwareRecommender()
   
   # Recommend with context
   recommendations = model.recommend(
       user_id=123,
       context={'time': 'evening', 'device': 'mobile', 'location': 'home'},
       top_k=10
   )

Traditional ML Algorithms
^^^^^^^^^^^^^^^^^^^^^^^^^

Machine learning-based content filtering:

**Decision Trees**

.. code-block:: python

   from corerec.engines.contentFilterEngine.traditional_ml_algorithms import decision_tree
   
   model = decision_tree.DecisionTreeRecommender()
   model.fit(features, labels)

**SVM**

.. code-block:: python

   from corerec.engines.contentFilterEngine.traditional_ml_algorithms import svm
   
   model = svm.SVMRecommender()
   model.fit(features, labels)

**LightGBM**

.. code-block:: python

   from corerec.engines.contentFilterEngine.traditional_ml_algorithms import lightgbm
   
   model = lightgbm.LightGBMRecommender()
   model.fit(features, labels)

Use Cases
---------

News Recommendations
^^^^^^^^^^^^^^^^^^^^

Recommend articles based on content similarity:

.. code-block:: python

   import pandas as pd
   from corerec.engines.contentFilterEngine import TFIDFRecommender
   
   # News articles
   articles = pd.DataFrame({
       'article_id': range(100),
       'title': [...],
       'content': [...],
       'category': [...]
   })
   
   # Recommend similar articles
   recommender = TFIDFRecommender()
   recommender.fit(articles, text_column='content')
   
   # User reads article 42
   user_read = 42
   similar_articles = recommender.recommend(item_id=user_read, top_k=5)

Movie Recommendations
^^^^^^^^^^^^^^^^^^^^^

Recommend movies based on plot descriptions and genres:

.. code-block:: python

   from corerec.engines.contentFilterEngine import TFIDFRecommender
   
   movies = pd.DataFrame({
       'movie_id': [...],
       'title': [...],
       'plot': [...],
       'genres': [...]  # e.g., 'Action|Thriller'
   })
   
   recommender = TFIDFRecommender()
   recommender.fit(movies, text_column='plot')
   
   # Recommend movies similar to movie 100
   similar_movies = recommender.recommend(item_id=100, top_k=10)

Product Recommendations
^^^^^^^^^^^^^^^^^^^^^^^

E-commerce product recommendations:

.. code-block:: python

   from corerec.engines.contentFilterEngine import TFIDFRecommender
   
   products = pd.DataFrame({
       'product_id': [...],
       'name': [...],
       'description': [...],
       'category': [...],
       'brand': [...]
   })
   
   # Combine multiple text fields
   products['combined_text'] = (
       products['name'] + ' ' + 
       products['description'] + ' ' + 
       products['category']
   )
   
   recommender = TFIDFRecommender()
   recommender.fit(products, text_column='combined_text')

Advanced Features
-----------------

Feature Engineering
^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.preprocessing import FeatureEngineer
   
   engineer = FeatureEngineer()
   
   # Extract features from text
   features = engineer.extract_text_features(
       items['description'],
       method='tfidf',
       max_features=1000,
       ngram_range=(1, 2)
   )
   
   # Extract categorical features
   cat_features = engineer.encode_categorical(
       items[['category', 'brand']],
       method='onehot'
   )

Multi-Modal Content
^^^^^^^^^^^^^^^^^^^

Combine text, images, and metadata:

.. code-block:: python

   from corerec.multimodal import MultiModalRecommender
   
   recommender = MultiModalRecommender(
       text_model='tfidf',
       image_model='cnn',
       combine_method='weighted_average'
   )
   
   recommender.fit(
       text_data=item_descriptions,
       image_data=item_images,
       metadata=item_metadata
   )

Best Practices
--------------

1. **Clean Text Data**
   
   * Remove HTML tags, special characters
   * Normalize whitespace
   * Handle different encodings

2. **Feature Selection**
   
   * Use domain knowledge
   * Remove irrelevant features
   * Handle missing values

3. **Handle Sparsity**
   
   * Use dimensionality reduction
   * Apply feature hashing for large vocabularies
   * Consider dense representations (embeddings)

4. **Optimize Performance**
   
   * Pre-compute item similarities
   * Cache frequent queries
   * Use approximate nearest neighbor search

5. **Evaluate Quality**
   
   * Diversity of recommendations
   * Coverage of item catalog
   * Novelty and serendipity

Limitations
-----------

Content-based filtering has some limitations:

* **Over-specialization**: Only recommends similar items
* **Limited serendipity**: Doesn't discover new types
* **Feature engineering**: Requires good features
* **New user problem**: Needs user preferences

**Solutions:**

* Combine with collaborative filtering (hybrid)
* Add exploration/randomization
* Use transfer learning for features
* Ask for explicit preferences

See Also
--------

* :doc:`unionized_filter` - Collaborative filtering
* :doc:`../algorithms/content_based` - Algorithm details
* :doc:`../examples/content_filter_examples` - More examples

