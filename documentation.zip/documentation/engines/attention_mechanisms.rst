Attention Mechanisms
====================

Attention-based models for sequential and session-based recommendations.

Overview
--------

Attention mechanisms allow models to focus on relevant parts of user history, improving recommendations for sequential data.

Available Models
----------------

SASRec (Self-Attentive Sequential Recommendation)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Transformer-based sequential recommendation.

.. autoclass:: corerec.engines.unionizedFilterEngine.attention_mechanism_base.SASRec_base
   :members:
   :show-inheritance:

**Example:**

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.attention_mechanism_base import SASRec_base
   
   model = SASRec_base(
       item_num=10000,
       max_len=50,
       hidden_units=64,
       num_blocks=2,
       num_heads=1,
       dropout_rate=0.2
   )
   
   model.fit(sequences, epochs=20)
   next_items = model.recommend(user_id=123, top_k=10)

**Key Features:**

* Self-attention mechanism
* Captures long-range dependencies
* Position embeddings
* State-of-the-art for sequential rec

Transformer-based Recommender
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Full transformer architecture for recommendations.

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.attention_mechanism_base import Transformer_based_uf_base
   
   model = Transformer_based_uf_base(
       num_items=10000,
       d_model=128,
       nhead=8,
       num_layers=6,
       dim_feedforward=512,
       dropout=0.1
   )
   
   model.fit(sequences, epochs=30)

**Key Features:**

* Multi-head attention
* Position-wise feed-forward
* Layer normalization
* Powerful but computationally expensive

BERT4Rec
^^^^^^^^

Bidirectional transformer for recommendations.

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.attention_mechanism_base import BERT4Rec
   
   model = BERT4Rec(
       num_items=10000,
       max_len=100,
       hidden_size=256,
       num_layers=2,
       num_heads=4,
       dropout=0.2
   )
   
   model.fit(sequences, epochs=20)

**Key Features:**

* Bidirectional attention
* Cloze task training
* Better context understanding
* Strong performance on various benchmarks

GRU4Rec
^^^^^^^

GRU-based session recommendations.

.. code-block:: python

   from corerec.engines.unionizedFilterEngine.attention_mechanism_base import GRU4Rec
   
   model = GRU4Rec(
       num_items=10000,
       hidden_size=100,
       num_layers=1,
       dropout=0.2
   )
   
   model.fit(sessions, epochs=15)

**Key Features:**

* Recurrent neural network
* Handles variable-length sequences
* Fast inference
* Good for session-based recommendations

Use Cases
---------

E-commerce Sequential Recommendations
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Next purchase prediction:

.. code-block:: python

   import pandas as pd
   from corerec.engines.unionizedFilterEngine.attention_mechanism_base import SASRec_base
   
   # User purchase sequences
   purchases = pd.DataFrame({
       'user_id': [1, 1, 1, 1, 2, 2, 2],
       'product_id': [101, 103, 105, 102, 201, 203, 205],
       'timestamp': [1, 2, 3, 4, 1, 2, 3]
   }).sort_values(['user_id', 'timestamp'])
   
   # Train SASRec
   model = SASRec_base(item_num=1000, max_len=20)
   model.fit(purchases, epochs=20)
   
   # Predict next purchases
   next_products = model.recommend(user_id=1, top_k=5)
   print("Predicted next purchases:", next_products)

Video Streaming Recommendations
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

What to watch next:

.. code-block:: python

   # Video watching history
   watch_history = pd.DataFrame({
       'user_id': [...],
       'video_id': [...],
       'watch_time': [...],  # Seconds watched
       'timestamp': [...]
   })
   
   # Weight by engagement
   watch_history['weight'] = watch_history['watch_time'] / 100
   
   model = SASRec_base(item_num=50000, max_len=50)
   model.fit(watch_history, epochs=20)
   
   # Recommend next videos
   next_videos = model.recommend(user_id=123, top_k=10)

Music Playlist Continuation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   # Listening sequences
   listening = pd.DataFrame({
       'user_id': [...],
       'song_id': [...],
       'play_count': [...],
       'timestamp': [...]
   })
   
   model = SASRec_base(item_num=100000, max_len=100)
   model.fit(listening, epochs=25)
   
   # Continue playlist
   next_songs = model.recommend(user_id=789, top_k=20)

Session-Based Recommendations
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Anonymous user sessions:

.. code-block:: python

   # Session data (no user IDs)
   sessions = pd.DataFrame({
       'session_id': [...],
       'item_id': [...],
       'timestamp': [...]
   })
   
   from corerec.engines.unionizedFilterEngine.attention_mechanism_base import GRU4Rec
   
   model = GRU4Rec(num_items=10000, hidden_size=100)
   model.fit(sessions, epochs=15)
   
   # Predict next items in session
   next_items = model.predict_next(session_id='abc123', top_k=5)

Advanced Features
-----------------

Multi-Head Attention
^^^^^^^^^^^^^^^^^^^^

Multiple attention heads for diverse patterns:

.. code-block:: python

   model = SASRec_base(
       item_num=10000,
       max_len=50,
       hidden_units=64,
       num_heads=4,  # 4 attention heads
       dropout_rate=0.2
   )

Positional Encoding
^^^^^^^^^^^^^^^^^^^

Encode sequence order:

.. code-block:: python

   # Learnable position embeddings
   model = SASRec_base(
       item_num=10000,
       max_len=50,
       position_encoding='learned'  # or 'sinusoidal'
   )

Attention Weights Visualization
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   # Get attention weights
   attention_weights = model.get_attention_weights(user_id=123)
   
   # Visualize
   import matplotlib.pyplot as plt
   import seaborn as sns
   
   plt.figure(figsize=(10, 8))
   sns.heatmap(attention_weights, cmap='viridis')
   plt.title('Attention Weights')
   plt.xlabel('Items')
   plt.ylabel('Sequence Position')
   plt.show()

Temporal Context
^^^^^^^^^^^^^^^^

Incorporate time information:

.. code-block:: python

   # Add time gaps as features
   sequences['time_gap'] = sequences.groupby('user_id')['timestamp'].diff()
   
   model = SASRec_base(
       item_num=10000,
       max_len=50,
       use_temporal_features=True
   )
   
   model.fit(sequences)

Training Strategies
-------------------

Negative Sampling
^^^^^^^^^^^^^^^^^

.. code-block:: python

   model.fit(
       sequences,
       epochs=20,
       negative_samples=5,  # 5 negative items per positive
       sampling_strategy='popularity'  # or 'uniform', 'hard'
   )

Curriculum Learning
^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   # Start with short sequences, gradually increase
   for max_len in [10, 20, 30, 50]:
       model = SASRec_base(item_num=10000, max_len=max_len)
       model.fit(sequences, epochs=5)

Data Augmentation
^^^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.preprocessing import SequenceAugmenter
   
   augmenter = SequenceAugmenter()
   
   # Augmentation techniques
   augmented = augmenter.augment(
       sequences,
       methods=['crop', 'mask', 'reorder'],
       aug_prob=0.2
   )
   
   model.fit(augmented, epochs=20)

Evaluation Metrics
------------------

For Sequential Recommendations
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   from corerec.evaluation import SequentialEvaluator
   
   evaluator = SequentialEvaluator(metrics=[
       'hit_rate@5',
       'hit_rate@10',
       'ndcg@5',
       'ndcg@10',
       'mrr'  # Mean Reciprocal Rank
   ])
   
   results = evaluator.evaluate(model, test_sequences)
   
   for metric, value in results.items():
       print(f"{metric}: {value:.4f}")

Next-Item Prediction
^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

   # Evaluate next-item prediction
   def evaluate_next_item(model, test_data):
       hits = 0
       total = 0
       
       for user_id in test_data['user_id'].unique():
           user_seq = test_data[test_data['user_id'] == user_id]
           
           # Use all but last item as history
           history = user_seq.iloc[:-1]['item_id'].tolist()
           target = user_seq.iloc[-1]['item_id']
           
           # Predict next item
           predictions = model.recommend(user_id=user_id, top_k=10)
           predicted_items = [item_id for item_id, _ in predictions]
           
           if target in predicted_items:
               hits += 1
           total += 1
       
       return hits / total

Best Practices
--------------

1. **Sequence Length**
   
   * Choose appropriate max_len (typically 20-100)
   * Consider computational cost vs. long-term dependencies
   * Use padding/truncation consistently

2. **Attention Configuration**
   
   * Start with 1-2 attention heads
   * Increase for complex patterns
   * Monitor attention weights for interpretability

3. **Position Encoding**
   
   * Use learnable embeddings for short sequences
   * Sinusoidal encoding for long sequences
   * Consider relative position encoding

4. **Training**
   
   * Use sufficient negative samples (3-5)
   * Implement early stopping
   * Monitor validation performance
   * Use learning rate scheduling

5. **Inference**
   
   * Cache user embeddings
   * Batch predictions when possible
   * Precompute item embeddings
   * Use approximate nearest neighbors

Common Challenges
-----------------

Long Sequences
^^^^^^^^^^^^^^

**Problem:** Computational cost and memory

**Solutions:**

* Truncate to recent items
* Use hierarchical attention
* Implement sparse attention
* Apply sequence compression

Cold Start
^^^^^^^^^^

**Problem:** New users/items

**Solutions:**

* Use content-based features
* Implement warm-up strategies
* Transfer learning from similar users
* Popularity-based initialization

Popularity Bias
^^^^^^^^^^^^^^^

**Problem:** Model favors popular items

**Solutions:**

* Balanced sampling
* Popularity-aware loss
* Debias in post-processing
* Diversity-promoting techniques

Model Comparison
----------------

.. list-table::
   :widths: 20 25 25 15 15
   :header-rows: 1

   * - Model
     - Best For
     - Complexity
     - Speed
     - Performance
   * - SASRec
     - General sequential
     - Medium
     - Fast
     - High
   * - BERT4Rec
     - Bidirectional context
     - High
     - Slow
     - Very High
   * - GRU4Rec
     - Sessions
     - Low
     - Very Fast
     - Medium
   * - Transformer
     - Long sequences
     - Very High
     - Slow
     - High

See Also
--------

* :doc:`../algorithms/neural_networks` - Neural network algorithms
* :doc:`../examples/neural_network_examples` - Usage examples
* :doc:`../advanced/training` - Advanced training techniques

