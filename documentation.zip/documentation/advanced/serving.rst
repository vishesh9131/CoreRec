Model Serving
=============

Deploy models for production serving.

Basic Serving
-------------

.. code-block:: python

   from corerec.serving import ModelServer
   
   server = ModelServer(
       model=model,
       host='0.0.0.0',
       port=8000
   )
   
   server.start()

See Also
--------

* :doc:`serialization` - Model serialization
* :doc:`pipelines` - Production pipelines

