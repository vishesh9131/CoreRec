Smoke Tests
===========

Smoke tests perform quick sanity checks on all models.

Running Smoke Tests
-------------------

.. code-block:: bash

   # Run smoke tests
   pytest tests/engines_models_smoke_test.py -v
   
   # Quick check all models work
   python corerec/run_algo_tests.py

Smoke Test Coverage
--------------------

The smoke tests verify:

* Model initialization
* Basic training
* Recommendation generation
* Prediction functionality

Models Tested
-------------

* **Content Filter**: TF-IDF, Neural Content Models
* **Matrix Factorization**: SVD, ALS, NMF
* **Neural Networks**: DeepFM, DCN, DIN, DIEN
* **Graph-Based**: GNN, LightGCN
* **Attention**: SASRec, Transformer

Example Output
--------------

.. code-block:: text

   ========== CoreRec Smoke Tests ==========
   Testing FM_base ✓
   Testing FFM_base ✓
   Testing DeepFM_base ✓
   Testing DCN_base ✓
   Testing GNN_base ✓
   Testing SASRec_base ✓
   
   All tests passed!

See Also
--------

* :doc:`overview` - Testing overview
* :doc:`unit_tests` - Unit tests

