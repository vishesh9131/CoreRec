Metrics Reference
=================

Evaluation metrics for recommendation systems.

Classification Metrics
----------------------

* **Precision@K**: Fraction of recommended items that are relevant
* **Recall@K**: Fraction of relevant items that are recommended
* **F1@K**: Harmonic mean of precision and recall
* **AUC**: Area Under ROC Curve
* **LogLoss**: Logarithmic loss

Ranking Metrics
---------------

* **NDCG@K**: Normalized Discounted Cumulative Gain
* **MAP@K**: Mean Average Precision
* **MRR**: Mean Reciprocal Rank
* **Hit Rate@K**: Fraction of users with at least one hit

Rating Metrics
--------------

* **RMSE**: Root Mean Squared Error
* **MAE**: Mean Absolute Error
* **R²**: Coefficient of Determination

Diversity Metrics
-----------------

* **Coverage**: Fraction of items recommended
* **Diversity**: Average dissimilarity of recommendations
* **Novelty**: Average popularity of recommendations

Usage
-----

.. code-block:: python

   from corerec.evaluation import Evaluator
   
   evaluator = Evaluator(metrics=[
       'precision@10',
       'recall@10',
       'ndcg@10',
       'coverage',
       'diversity'
   ])
   
   results = evaluator.evaluate(model, test_data)

See Also
--------

* :doc:`../engines/overview` - Engine documentation
* :doc:`utilities` - Other utilities

