Utilities Reference
===================

Utility functions and helper modules.

Data Utilities
--------------

.. automodule:: corerec.cr_utility.dataloader
   :members:
   :undoc-members:

.. automodule:: corerec.cr_utility.dataset
   :members:
   :undoc-members:

Metrics
-------

.. automodule:: corerec.metrics
   :members:
   :undoc-members:

Visualization
-------------

.. automodule:: corerec.visualization
   :members:
   :undoc-members:

Format Master
-------------

.. automodule:: corerec.format_master.ds_format_loader
   :members:
   :undoc-members:

See Also
--------

* :doc:`modules` - All modules
* :doc:`preprocessing` - Preprocessing utilities

