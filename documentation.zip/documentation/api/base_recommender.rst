Base Recommender API
====================

The ``BaseRecommender`` class is the foundation of all recommendation models in CoreRec.

Overview
--------

All recommendation algorithms in CoreRec inherit from ``BaseRecommender``, ensuring a consistent interface across different models.

Class Definition
----------------

.. autoclass:: corerec.api.base_recommender.BaseRecommender
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __init__

Core Methods
------------

fit
^^^

Train the recommendation model on data.

.. code-block:: python

   def fit(self, data, **kwargs):
       """
       Train the recommendation model.
       
       Parameters
       ----------
       data : pd.DataFrame
           Training data with columns: user_id, item_id, rating (optional)
       **kwargs : dict
           Additional training parameters
       
       Returns
       -------
       self : BaseRecommender
           Trained model instance
       """

Example:

.. code-block:: python

   model.fit(
       train_data,
       epochs=10,
       batch_size=32,
       learning_rate=0.001
   )

recommend
^^^^^^^^^

Generate top-k recommendations for a user.

.. code-block:: python

   def recommend(self, user_id, top_k=10, filter_seen=True):
       """
       Generate recommendations for a user.
       
       Parameters
       ----------
       user_id : int
           User identifier
       top_k : int, default=10
           Number of recommendations to generate
       filter_seen : bool, default=True
           Whether to filter out items the user has already interacted with
       
       Returns
       -------
       recommendations : list of tuples
           List of (item_id, score) tuples sorted by score
       """

Example:

.. code-block:: python

   # Get top 5 recommendations for user 123
   recs = model.recommend(user_id=123, top_k=5)
   
   for item_id, score in recs:
       print(f"Item {item_id}: {score:.3f}")

predict
^^^^^^^

Predict score for a specific user-item pair.

.. code-block:: python

   def predict(self, user_id, item_id):
       """
       Predict score for a user-item pair.
       
       Parameters
       ----------
       user_id : int
           User identifier
       item_id : int
           Item identifier
       
       Returns
       -------
       score : float
           Predicted score/rating
       """

Example:

.. code-block:: python

   # Predict rating for user 123 and item 456
   score = model.predict(user_id=123, item_id=456)
   print(f"Predicted score: {score:.2f}")

save & load
^^^^^^^^^^^

Model persistence methods.

.. code-block:: python

   def save(self, path):
       """
       Save model to disk.
       
       Parameters
       ----------
       path : str
           File path to save the model
       """
   
   @classmethod
   def load(cls, path):
       """
       Load model from disk.
       
       Parameters
       ----------
       path : str
           File path to load the model from
       
       Returns
       -------
       model : BaseRecommender
           Loaded model instance
       """

Example:

.. code-block:: python

   # Save model
   model.save('my_recommender.pkl')
   
   # Load model
   from corerec.engines.unionizedFilterEngine import MatrixFactorization
   loaded_model = MatrixFactorization.load('my_recommender.pkl')

Optional Methods
----------------

fit_partial
^^^^^^^^^^^

Incremental training for online learning.

.. code-block:: python

   def fit_partial(self, data, **kwargs):
       """
       Update model with new data (online learning).
       
       Parameters
       ----------
       data : pd.DataFrame
           New training data
       **kwargs : dict
           Additional parameters
       """

get_user_embedding
^^^^^^^^^^^^^^^^^^

Get user representation/embedding.

.. code-block:: python

   def get_user_embedding(self, user_id):
       """
       Get learned embedding for a user.
       
       Parameters
       ----------
       user_id : int
           User identifier
       
       Returns
       -------
       embedding : np.ndarray
           User embedding vector
       """

get_item_embedding
^^^^^^^^^^^^^^^^^^

Get item representation/embedding.

.. code-block:: python

   def get_item_embedding(self, item_id):
       """
       Get learned embedding for an item.
       
       Parameters
       ----------
       item_id : int
           Item identifier
       
       Returns
       -------
       embedding : np.ndarray
           Item embedding vector
       """

Implementation Example
----------------------

Here's how to implement a custom recommender:

.. code-block:: python

   from corerec.api.base_recommender import BaseRecommender
   import numpy as np
   import pandas as pd
   
   class SimpleMatrixFactorization(BaseRecommender):
       """Simple matrix factorization recommender."""
       
       def __init__(self, n_factors=20, learning_rate=0.01, n_epochs=20):
           super().__init__()
           self.n_factors = n_factors
           self.learning_rate = learning_rate
           self.n_epochs = n_epochs
           self.user_factors = None
           self.item_factors = None
           self.user_bias = None
           self.item_bias = None
           self.global_bias = None
       
       def fit(self, data):
           """Train the model using SGD."""
           # Initialize
           n_users = data['user_id'].nunique()
           n_items = data['item_id'].nunique()
           
           self.user_factors = np.random.randn(n_users, self.n_factors) * 0.01
           self.item_factors = np.random.randn(n_items, self.n_factors) * 0.01
           self.user_bias = np.zeros(n_users)
           self.item_bias = np.zeros(n_items)
           self.global_bias = data['rating'].mean()
           
           # Train
           for epoch in range(self.n_epochs):
               for _, row in data.iterrows():
                   user_id = row['user_id']
                   item_id = row['item_id']
                   rating = row['rating']
                   
                   # Compute prediction
                   pred = self.predict(user_id, item_id)
                   error = rating - pred
                   
                   # Update factors
                   self.user_factors[user_id] += self.learning_rate * error * self.item_factors[item_id]
                   self.item_factors[item_id] += self.learning_rate * error * self.user_factors[user_id]
                   self.user_bias[user_id] += self.learning_rate * error
                   self.item_bias[item_id] += self.learning_rate * error
           
           return self
       
       def predict(self, user_id, item_id):
           """Predict rating for user-item pair."""
           pred = self.global_bias
           pred += self.user_bias[user_id]
           pred += self.item_bias[item_id]
           pred += np.dot(self.user_factors[user_id], self.item_factors[item_id])
           return pred
       
       def recommend(self, user_id, top_k=10, filter_seen=True):
           """Generate top-k recommendations."""
           # Compute scores for all items
           user_vec = self.user_factors[user_id]
           scores = self.item_factors @ user_vec + self.item_bias + self.global_bias
           scores += self.user_bias[user_id]
           
           # Get top-k
           top_indices = np.argsort(scores)[-top_k:][::-1]
           
           return [(idx, scores[idx]) for idx in top_indices]
       
       def get_user_embedding(self, user_id):
           """Get user embedding."""
           return self.user_factors[user_id]
       
       def get_item_embedding(self, item_id):
           """Get item embedding."""
           return self.item_factors[item_id]

Usage:

.. code-block:: python

   # Initialize
   model = SimpleMatrixFactorization(n_factors=50, learning_rate=0.01)
   
   # Train
   model.fit(train_data)
   
   # Recommend
   recommendations = model.recommend(user_id=1, top_k=10)
   
   # Get embeddings
   user_emb = model.get_user_embedding(1)
   item_emb = model.get_item_embedding(100)

Best Practices
--------------

1. **Always call parent __init__**: Ensure proper initialization

   .. code-block:: python
   
      def __init__(self, param1, param2):
          super().__init__()
          self.param1 = param1

2. **Validate inputs**: Check data format and parameters

   .. code-block:: python
   
      def fit(self, data):
          if 'user_id' not in data.columns:
              raise ValueError("Data must contain 'user_id' column")

3. **Return self from fit**: Enable method chaining

   .. code-block:: python
   
      def fit(self, data):
          # Training code
          return self

4. **Handle edge cases**: Deal with unknown users/items

   .. code-block:: python
   
      def recommend(self, user_id, top_k=10):
          if user_id >= len(self.user_factors):
              return self._handle_cold_start(user_id, top_k)

5. **Implement save/load**: Enable model persistence

   .. code-block:: python
   
      def save(self, path):
          import pickle
          with open(path, 'wb') as f:
              pickle.dump(self.__dict__, f)

See Also
--------

* :doc:`model_interface` - Model lifecycle management
* :doc:`predictor_interface` - Prediction interface
* :doc:`../engines/overview` - Built-in recommendation engines
* :doc:`../examples/overview` - Usage examples

