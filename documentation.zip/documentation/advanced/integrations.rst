Integrations
============

Integrate CoreRec with other tools and frameworks.

Supported Integrations
-----------------------

* MLflow for experiment tracking
* TensorBoard for visualization
* Ray for distributed training
* FastAPI for serving
* Apache Kafka for streaming

See Also
--------

* :doc:`serving` - Model serving
* :doc:`../api/overview` - API documentation

