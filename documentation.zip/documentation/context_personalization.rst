context\_personalization package
================================

Submodules
----------

context\_personalization.context\_aware module
----------------------------------------------

.. automodule:: context_personalization.context_aware
   :members:
   :undoc-members:
   :show-inheritance:

context\_personalization.item\_profiling module
-----------------------------------------------

.. automodule:: context_personalization.item_profiling
   :members:
   :undoc-members:
   :show-inheritance:

context\_personalization.user\_profiling module
-----------------------------------------------

.. automodule:: context_personalization.user_profiling
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: context_personalization
   :members:
   :undoc-members:
   :show-inheritance:
