# Configuration file for the Sphinx documentation builder.
#
# For the full list of built-in configuration values, see the documentation:
# https://www.sphinx-doc.org/en/master/usage/configuration.html

# -- Project information -----------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#project-information
import os
import sys

# Add paths to Python path for autodoc
sys.path.insert(0, os.path.abspath('..'))
sys.path.insert(0, os.path.abspath('../corerec'))
sys.path.insert(0, os.path.abspath('../corerec/engines'))
sys.path.insert(0, os.path.abspath('../corerec/engines/contentFilterEngine'))
sys.path.insert(0, os.path.abspath('../corerec/engines/unionizedFilterEngine'))
sys.path.insert(0, os.path.abspath('../tests'))
sys.path.insert(0, os.path.abspath('../examples'))

project = 'CoreRec'
copyright = '2024-2025, Vishesh Yadav'
author = 'Vishesh Yadav'
release = '0.5.0'
version = '0.5.0'

# -- General configuration ---------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#general-configuration

extensions = [
    'sphinx.ext.autodoc',
    'sphinx.ext.napoleon',
    'sphinx.ext.viewcode',
    'sphinx.ext.todo',
    'sphinx.ext.coverage',
    'sphinx.ext.intersphinx',
    'sphinx.ext.autosummary',
    'sphinx.ext.githubpages',
    'sphinx_design',
]

# Napoleon settings for Google and NumPy style docstrings
napoleon_google_docstring = True
napoleon_numpy_docstring = True
napoleon_include_init_with_doc = True
napoleon_include_private_with_doc = False
napoleon_include_special_with_doc = True
napoleon_use_admonition_for_examples = True
napoleon_use_admonition_for_notes = True
napoleon_use_admonition_for_references = True
napoleon_use_ivar = True
napoleon_use_param = True
napoleon_use_rtype = True

# Autodoc settings
autodoc_default_options = {
    'members': True,
    'member-order': 'bysource',
    'special-members': '__init__',
    'undoc-members': True,
    'exclude-members': '__weakref__'
}
autodoc_typehints = 'description'
autodoc_mock_imports = ['torch', 'numpy', 'pandas', 'sklearn', 'scipy', 
                        'matplotlib', 'seaborn', 'networkx', 'tensorflow',
                        'keras', 'lightgbm', 'xgboost', 'fastai', 'vowpalwabbit',
                        'torch_geometric', 'yaml', 'nltk', 'owlready2', 'h5py',
                        'pyarrow', 'feather', 'avro', 'pystan', 'msgpack', 'pyorc',
                        'sqlalchemy', 'pymongo', 'gspread', 'textract']

# Suppress warnings for missing modules
suppress_warnings = ['app.add_directive', 'app.add_role', 'autosummary']

# Continue on missing imports
autodoc_inherit_docstrings = True

# Autosummary settings
autosummary_generate = False  # Disable autosummary generation
autosummary_imported_members = False

templates_path = ['_templates']
exclude_patterns = ['_build', 'Thumbs.db', '.DS_Store']

# Intersphinx mapping
intersphinx_mapping = {
    'python': ('https://docs.python.org/3', None),
    'numpy': ('https://numpy.org/doc/stable/', None),
    'pandas': ('https://pandas.pydata.org/docs/', None),
    'torch': ('https://pytorch.org/docs/stable/', None),
}

# -- Options for HTML output -------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#options-for-html-output
# html_theme = 'sphinxawesome_theme'

html_theme = 'furo'
html_theme_options = {
    "logo_light": "_static/lgt.png",
    "logo_dark": "_static/drk.png",
    "show_scrolltop": True,
}

html_static_path = ['_static']
html_title = f"{project} {version} Documentation"
html_short_title = f"{project} {version}"

# Show todos
todo_include_todos = True

# Source suffix
source_suffix = '.rst'

# The master toctree document
master_doc = 'index'

# Language
language = 'en'
