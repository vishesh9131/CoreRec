Deep Learning Methods
=====================

Advanced deep learning for recommendations.

See Also
--------

* :doc:`neural_networks` - Neural network algorithms
* :doc:`../engines/neural_networks` - Neural network engine

