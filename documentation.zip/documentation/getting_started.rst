Getting Started with CoreRec
============================

Welcome to CoreRec! This page will help you quickly understand and start using CoreRec for building recommendation systems.

.. contents:: On this page
   :local:
   :depth: 2

What is CoreRec?
---------------

CoreRec is a comprehensive Python library for building state-of-the-art recommendation systems.

**Key Features:**

* Multiple recommendation algorithms (collaborative, content-based, deep learning)
* Production-ready components (serving, pipelines, serialization)
* Easy-to-use APIs for quick prototyping
* Scalable architecture for research and production

.. seealso::
   
   * :doc:`installation` - How to install CoreRec
   * :doc:`quickstart` - 5-minute quickstart tutorial
   * :doc:`examples/overview` - Complete examples

Core Concepts
-------------

Recommendation Engines
^^^^^^^^^^^^^^^^^^^^^

CoreRec provides two main engines:

.. list-table::
   :widths: 30 70
   :header-rows: 1

   * - Engine
     - Description
   * - **ContentFilterEngine**
     - Content-based filtering using item features (TF-IDF, Neural Networks)
   * - **UnionizedFilterEngine**
     - Collaborative filtering using interactions (Matrix Factorization, Deep Learning, Graphs)

.. tip::
   
   **New users:** Start with :doc:`quickstart` for hands-on examples!

Base Recommender Interface
^^^^^^^^^^^^^^^^^^^^^^^^^^

All models follow a consistent interface:

.. code-block:: python

   model.fit(data)                        # Train
   model.recommend(user_id, top_k=10)     # Get recommendations
   model.predict(user_id, item_id)        # Predict score
   model.save('model.pkl')                # Save model

Data Format
^^^^^^^^^^^

.. collapse:: Click to see data format details

   **User-Item Interactions:**

   .. code-block:: python

      import pandas as pd
      
      data = pd.DataFrame({
          'user_id': [1, 1, 2, 2, 3],
          'item_id': [101, 102, 101, 103, 102],
          'rating': [5, 4, 3, 5, 4]
      })

   **Item Features** (optional):

   .. code-block:: python

      items = pd.DataFrame({
          'item_id': [101, 102, 103],
          'title': ['Movie A', 'Movie B', 'Movie C'],
          'description': ['...', '...', '...']
      })

Quick Example
-------------

Here's a complete example in just a few lines:

.. code-block:: python

   from corerec.engines.unionizedFilterEngine import MatrixFactorization
   import pandas as pd
   
   # Your data
   ratings = pd.DataFrame({
       'user_id': [1, 1, 2, 2, 3],
       'item_id': [101, 102, 103, 104, 105],
       'rating': [5, 4, 3, 5, 4]
   })
   
   # Train model
   model = MatrixFactorization(n_factors=10)
   model.fit(ratings)
   
   # Get recommendations
   recs = model.recommend(user_id=1, top_k=5)
   print(recs)

.. note::
   
   This is just a simple example. See :doc:`quickstart` for more detailed tutorials!

Common Use Cases
----------------

.. grid:: 2
   :gutter: 3

   .. grid-item-card:: 🛍️ E-commerce
      :link: examples/real_world_examples
      :link-type: doc
      
      Product recommendations based on purchase history

   .. grid-item-card:: 🎬 Streaming
      :link: examples/real_world_examples
      :link-type: doc
      
      Movie/music recommendations

   .. grid-item-card:: 📱 Social Media
      :link: examples/real_world_examples
      :link-type: doc
      
      Content and connection suggestions

   .. grid-item-card:: 📰 News
      :link: examples/real_world_examples
      :link-type: doc
      
      Personalized article recommendations

Next Steps
----------

.. grid:: 2
   :gutter: 3

   .. grid-item-card:: 🚀 Quickstart Tutorial
      :link: quickstart
      :link-type: doc
      
      5-minute tutorial with complete examples

   .. grid-item-card:: 📚 Examples
      :link: examples/overview
      :link-type: doc
      
      Real-world examples and use cases

   .. grid-item-card:: 🔧 Engine Documentation
      :link: engines/overview
      :link-type: doc
      
      Learn about available algorithms

   .. grid-item-card:: 📖 API Reference
      :link: api/overview
      :link-type: doc
      
      Detailed API documentation

Troubleshooting
---------------

.. dropdown:: **Import Errors**

   Ensure CoreRec is properly installed:

   .. code-block:: bash

      pip install --upgrade corerec

.. dropdown:: **Memory Issues**

   For large datasets:
   
   * Use sparse matrices
   * Implement batch processing
   * Use sampling for training
   * Try distributed computing

.. dropdown:: **Poor Recommendations**

   Common fixes:
   
   * Check data quality
   * Tune hyperparameters
   * Try different algorithms
   * Add more training data
   * Engineer better features

Need Help?
----------

.. grid:: 2
   :gutter: 2

   .. grid-item-card:: 💬 Community
      
      * `GitHub Issues <https://github.com/vishesh9131/corerec/issues>`_
      * `CoreRec Community <https://corerec.tech>`_

   .. grid-item-card:: 📧 Contact
      
      * Email: vishesh@corerec.tech
      * More examples: :doc:`examples/overview`

