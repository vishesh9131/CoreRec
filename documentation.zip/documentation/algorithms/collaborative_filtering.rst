Collaborative Filtering Algorithms
===================================

Detailed documentation of collaborative filtering algorithms.

Matrix Factorization
---------------------

Decompose user-item matrix into latent factors.

See Also
--------

* :doc:`../engines/matrix_factorization` - Matrix factorization engine
* :doc:`../examples/unionized_filter_examples` - Examples

